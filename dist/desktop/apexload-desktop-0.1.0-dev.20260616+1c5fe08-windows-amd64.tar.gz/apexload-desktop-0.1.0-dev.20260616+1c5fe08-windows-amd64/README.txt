APEX Load Desktop 0.1.0-dev.20260616+1c5fe08

This package contains the optional Wails desktop workspace. The desktop app runs
an embedded local controller for local authoring and runs, and it can connect to
Remote Workspaces for sync and remote execution.

macOS Gatekeeper:

Production macOS desktop packages must be built with a Developer ID Application
certificate and Apple notarization before distribution. Local development
packages built without APEXLOAD_MACOS_CODESIGN_IDENTITY are ad-hoc signed only;
macOS may show "Apple could not verify 'apexload.app' is free of malware." For
local development only, after verifying this archive came from your own build
and the SHA256SUMS.txt entry matches, clear the quarantine attribute:

  xattr -dr com.apple.quarantine ./apexload.app

Release packaging needs user-supplied macOS Developer ID/notarytool credentials
and Windows signtool certificate material in CI.
