APEX Load Desktop 0.1.0-dev.20260613+1ed5758

This package contains the optional Wails desktop workspace. The desktop app runs
an embedded local controller for local authoring and runs, and it can connect to
Remote Workspaces for sync and remote execution.

Signed installers are intentionally not produced by this scaffold. Production
distribution needs user-supplied macOS Developer ID/notarytool credentials and
Windows signtool certificate material in CI.
