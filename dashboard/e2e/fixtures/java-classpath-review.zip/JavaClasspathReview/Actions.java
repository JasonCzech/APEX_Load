public class Actions {
  public int init() { return 0; }
  public int action() { String password = "synthetic-browser-source-password"; return 0; }
  public int end() { return 0; }
}
