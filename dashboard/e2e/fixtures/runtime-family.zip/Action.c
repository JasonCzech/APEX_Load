Action(){ web_url("Page", "URL=https://example.test/", LAST); return 0; }
