Action() {
web_custom_request("Protected POST", "URL=https://example.test/submit", "Method=POST", "EncType=application/json", "Body={}", LAST);
return 0;
}
