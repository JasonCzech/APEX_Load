Action() {
  web_reg_find("Text=ready", "Search=ALL", LAST);
  web_url("Status", "URL=https://example.test/status", "Resource=0", LAST);
  return 0;
}
