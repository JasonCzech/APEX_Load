Action() {
web_add_auto_header("Cookie", "session=test-only-cookie");
web_url("First", "URL=https://login.salesforce.com/services/oauth2/authorize?client_id=test-application", "Resource=0", LAST);
web_url("Second", "URL=https://login.salesforce.com/status", "Resource=0", LAST);
return 0;
}