# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-analysis-preparation.spec.ts >> mapping reassociation preserves declared measurements with bad-echo
- Location: e2e/workflow-analysis-preparation.spec.ts:646:3

# Error details

```
TimeoutError: locator.selectOption: Timeout 15000ms exceeded.
Call log:
  - waiting for getByRole('region', { name: 'Analysis workspace', exact: true }).getByRole('region', { name: 'Dataset comparison', exact: true }).getByLabel('Compare with', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=f1e3]:
  - link "Skip to main content" [ref=f1e4] [cursor=pointer]:
    - /url: "#app-main"
  - complementary [ref=f1e6] [cursor=pointer]:
    - button "APEX Load dashboard" [ref=f1e7]:
      - img "APEX Load" [ref=f1e8]
    - button "Workspace context. e2e-1792489118945-580413 domain / e2e-1792489118945-580413 project / e2e-1792489118945-580413 application / e2e-1792489118945-580413 1.0" [ref=f1e15]:
      - generic [aria-hidden] [ref=f1e16]: ◈
    - navigation "Primary navigation" [ref=f1e17]:
      - button "New run" [ref=f1e19]
      - generic [ref=f1e24]:
        - button "Dashboard" [ref=f1e26]
        - button "Command Center" [ref=f1e34]
        - button "Results" [ref=f1e41]
        - button "Monitoring" [ref=f1e45]
        - button "Activity" [ref=f1e50]
      - generic [ref=f1e54]:
        - button "Scripts" [ref=f1e56]
        - button "Scenarios" [ref=f1e62]
        - button "Shared assets" [ref=f1e67]
      - generic [ref=f1e73]:
        - button "Repository" [ref=f1e75]
        - button "Access" [ref=f1e81]
        - button "Settings" [ref=f1e88]
      - button "Help & documentation" [ref=f1e95]
    - generic [ref=f1e100]:
      - generic [ref=f1e101]:
        - 'button "Preview permissions. Current mode: Admin" [ref=f1e104]':
          - generic [aria-hidden] [ref=f1e105]: DEV
        - generic [ref=f1e106]:
          - 'status "Live connection: Live" [ref=f1e107]':
            - generic [ref=f1e109]:
              - generic [ref=f1e110]: "Live connection:"
              - text: Live
          - 'button "Build info: local · dev" [ref=f1e112]'
      - button "Expand sidebar" [ref=f1e115]
  - main [ref=f1e118]:
    - status [ref=f1e119]: Monitoring
    - generic "Dashboard controls" [ref=f1e120]:
      - heading "Monitoring" [level=1] [ref=f1e122]
      - generic [ref=f1e124]:
        - tablist "Monitor categories" [ref=f1e125]:
          - tab "Overview" [selected] [ref=f1e126] [cursor=pointer]
          - tab "Fleet" [ref=f1e128] [cursor=pointer]
          - tab "Telemetry" [ref=f1e130] [cursor=pointer]
          - tab "Alerts" [ref=f1e132] [cursor=pointer]
          - tab "Schedules" [ref=f1e134] [cursor=pointer]
        - button "1 advisory warning. View system advisories" [ref=f1e136] [cursor=pointer]: 1 advisory warning
      - generic [ref=f1e137]:
        - link "Help for this page" [ref=f1e138] [cursor=pointer]:
          - /url: "#/docs?guide=user-guide&article=execution&section=monitoring-a-live-run"
        - generic "Deployment identity" [ref=f1e139]:
          - generic "You are using APEX Load in a web browser; tests run on the Server controller." [ref=f1e140]:
            - text: Web app · Server
            - generic [ref=f1e142]: . You are using APEX Load in a web browser; tests run on the Server controller.
        - combobox "Dashboard color theme" [ref=f1e144] [cursor=pointer]:
          - option "System (Auto)"
          - option "Dark Theme"
          - option "Light Theme" [selected]
          - option "Solarized Dark"
          - option "Solarized Light"
          - option "Monokai Dimmed"
    - generic [ref=f1e145]:
      - status [ref=f1e146]: Readiness Degraded · Auth Mode. Kubernetes API Not applicable. Metadata Store Ready. Cache Backend Ready.
      - generic [ref=f1e147]:
        - generic [ref=f1e148]: "Project: e2e-1792489118945-580413 project · Control-plane health is deployment-wide."
        - link "Controller settings" [ref=f1e149] [cursor=pointer]:
          - /url: "#/settings?setting=platform&returnTo=%23%2Fmonitoring%3FprojectId%3D69582d0c-5700-4931-8f73-e88ee99e09e0%26applicationId%3D5658c321-4f7c-46f9-9969-54a94d45612c%26releaseId%3D80cd2505-2598-442f-906d-98cfe662e48f&projectId=69582d0c-5700-4931-8f73-e88ee99e09e0&applicationId=5658c321-4f7c-46f9-9969-54a94d45612c&releaseId=80cd2505-2598-442f-906d-98cfe662e48f"
        - link "Authentication" [ref=f1e150] [cursor=pointer]:
          - /url: "#/access?setting=authentication&returnTo=%23%2Fmonitoring%3FprojectId%3D69582d0c-5700-4931-8f73-e88ee99e09e0%26applicationId%3D5658c321-4f7c-46f9-9969-54a94d45612c%26releaseId%3D80cd2505-2598-442f-906d-98cfe662e48f&projectId=69582d0c-5700-4931-8f73-e88ee99e09e0&applicationId=5658c321-4f7c-46f9-9969-54a94d45612c&releaseId=80cd2505-2598-442f-906d-98cfe662e48f"
      - tabpanel "Overview monitors" [ref=f1e151]:
        - generic [ref=f1e152]:
          - generic [ref=f1e153]:
            - generic [ref=f1e154]:
              - generic [ref=f1e158]: Readiness & Services
              - generic [ref=f1e159]: Degraded · Auth Mode
            - generic [ref=f1e160]:
              - generic [ref=f1e161]:
                - generic [ref=f1e162]: Ready Checks
                - generic [ref=f1e163]: 9/10
              - generic [ref=f1e164]:
                - generic [ref=f1e165]: Degraded
                - generic [ref=f1e166]: "1"
              - generic [ref=f1e167]:
                - generic [ref=f1e168]: Blocked
                - generic [ref=f1e169]: "0"
              - generic [ref=f1e170]:
                - generic [ref=f1e171]: Services
                - generic [ref=f1e172]: 3/3 active
              - list "Infrastructure readiness" [ref=f1e173]:
                - listitem [ref=f1e174]:
                  - generic [ref=f1e175]:
                    - generic [ref=f1e176]: Kubernetes API
                    - generic [ref=f1e177]: This runtime does not use this optional integration.
                  - generic [ref=f1e178]: Not applicable
                - listitem [ref=f1e179]:
                  - generic [ref=f1e180]:
                    - generic [ref=f1e181]: SQLite Metadata Store
                    - generic [ref=f1e182]: metadata store is reachable · 0.094 ms
                  - generic [ref=f1e183]: Ready
                - listitem [ref=f1e184]:
                  - generic [ref=f1e185]:
                    - generic [ref=f1e186]: In-memory Cache
                    - generic [ref=f1e187]: in-memory cache backend is ready · 0 ms
                  - generic [ref=f1e188]: Ready
              - paragraph [ref=f1e190]: "Auth Mode: auth bypass mode is active; suitable for local development only"
              - generic [ref=f1e191]:
                - generic [ref=f1e192]: Backend
                - generic [ref=f1e193]:
                  - generic [ref=f1e194]:
                    - generic [ref=f1e195]:
                      - generic [ref=f1e196]: Controller API
                      - generic [ref=f1e197]: http://127.0.0.1:18139
                    - generic [ref=f1e198]: running
                  - generic [ref=f1e199]:
                    - generic [ref=f1e200]:
                      - generic [ref=f1e201]: Recorder Proxy
                      - generic [ref=f1e202]: http://127.0.0.1:56032
                    - generic [ref=f1e203]: idle
              - generic [ref=f1e204]:
                - generic [ref=f1e205]: Frontend
                - generic [ref=f1e207]:
                  - generic [ref=f1e208]:
                    - generic [ref=f1e209]: Dashboard
                    - generic [ref=f1e210]: http://127.0.0.1:18139
                  - generic [ref=f1e211]: running
          - generic [ref=f1e212]:
            - generic [ref=f1e213]: Analysis workspace
            - region "Analysis workspace" [ref=f1e219]:
              - paragraph [ref=f1e220]: Import Parquet metric observations, inspect their schema, and compare measurements on a UTC timeline.
              - generic [ref=f1e221]:
                - complementary "Datasets" [ref=f1e222]:
                  - heading "Datasets and imports" [level=3] [ref=f1e223]
                  - button "New import" [ref=f1e224] [cursor=pointer]
                  - list [ref=f1e225]:
                    - listitem [ref=f1e226]:
                      - button "Declared measurements · ready" [active] [ref=f1e227] [cursor=pointer]:
                        - strong [ref=f1e228]: Declared measurements
                        - generic [ref=f1e229]:
                          - generic [ref=f1e230]: ·
                          - text: ready
                - generic [ref=f1e231]:
                  - heading "Declared measurements" [level=3] [ref=f1e232]
                  - paragraph [ref=f1e233]: "State: ready · Accepted: 2 · Rejected: 0"
                  - group "Query dataset" [ref=f1e234]:
                    - generic [ref=f1e236]:
                      - text: Metric
                      - combobox "Metric" [ref=f1e237]: latency
                    - generic [ref=f1e238]:
                      - text: From (UTC)
                      - textbox "From (UTC)" [ref=f1e239]
                    - generic [ref=f1e240]:
                      - text: To (UTC)
                      - textbox "To (UTC)" [ref=f1e241]
                    - generic [ref=f1e242]:
                      - text: Bucket (seconds, optional)
                      - spinbutton "Bucket (seconds, optional)" [ref=f1e243]
                    - generic [ref=f1e244]:
                      - text: Summary statistic
                      - combobox "Summary statistic" [ref=f1e245]:
                        - option "p95" [selected]
                    - group "Dataset identity filters" [ref=f1e246]:
                      - paragraph [ref=f1e248]: Select one source and label combination when a metric has several series. An empty dimension value matches an explicit empty label.
                      - generic [ref=f1e249]:
                        - text: Source ID
                        - textbox "Source ID" [ref=f1e250]
                      - generic [ref=f1e251]:
                        - text: Host
                        - textbox "Host" [ref=f1e252]
                      - generic [ref=f1e253]:
                        - text: Service
                        - textbox "Service" [ref=f1e254]
                      - button "Add dimension filter" [ref=f1e255] [cursor=pointer]
                    - button "Show series" [disabled] [ref=f1e256]
                  - region "Dataset comparison" [ref=f1e257]:
                    - heading "Compare and correlate" [level=3] [ref=f1e258]
                    - paragraph [ref=f1e259]: Correlation measures association. Missing evidence stays missing; it does not establish a cause.
                    - group "Evidence selection" [ref=f1e260]:
                      - generic [ref=f1e262]:
                        - text: Saved comparison
                        - combobox "Saved comparison" [ref=f1e263]:
                          - option "Choose a saved comparison…" [selected]
                      - generic [ref=f1e264]:
                        - text: Dataset metric
                        - textbox "Dataset metric" [ref=f1e265]: latency
                      - group "Dataset identity filters" [ref=f1e266]:
                        - paragraph [ref=f1e268]: Select one source and label combination when a metric has several series. An empty dimension value matches an explicit empty label.
                        - generic [ref=f1e269]:
                          - text: Source ID
                          - textbox "Source ID" [ref=f1e270]
                        - generic [ref=f1e271]:
                          - text: Host
                          - textbox "Host" [ref=f1e272]
                        - generic [ref=f1e273]:
                          - text: Service
                          - textbox "Service" [ref=f1e274]
                        - button "Add dimension filter" [ref=f1e275] [cursor=pointer]
                      - generic [ref=f1e276]:
                        - text: Compare with
                        - combobox "Compare with" [ref=f1e277]:
                          - option "Select evidence…" [selected]
                          - option "Managed run"
                      - generic [ref=f1e278]:
                        - text: Comparison metric
                        - textbox "Comparison metric" [ref=f1e279]
                      - generic [ref=f1e280]:
                        - text: From (UTC)
                        - textbox "From (UTC)" [ref=f1e281]
                      - generic [ref=f1e282]:
                        - text: To (UTC)
                        - textbox "To (UTC)" [ref=f1e283]
                      - generic [ref=f1e284]:
                        - text: Bucket seconds
                        - spinbutton "Bucket seconds" [ref=f1e285]: "10"
                      - generic [ref=f1e286]:
                        - text: Dataset aggregation
                        - combobox "Dataset aggregation" [ref=f1e287]:
                          - option "avg" [selected]
                          - option "p95"
                      - generic [ref=f1e288]:
                        - text: Comparison aggregation
                        - combobox "Comparison aggregation" [ref=f1e289]:
                          - option "avg" [selected]
                          - option "min"
                          - option "max"
                          - option "sum"
                          - option "count"
                          - option "p50"
                          - option "p95"
                          - option "p99"
                          - option "rate"
                      - generic [ref=f1e290]:
                        - text: Analysis
                        - combobox "Analysis" [ref=f1e291]:
                          - option "Overlay compatible measurements" [selected]
                          - option "Lagged correlation"
                      - button "Analyze comparison" [disabled] [ref=f1e292]
                      - generic [ref=f1e293]:
                        - text: Saved comparison name
                        - textbox "Saved comparison name" [ref=f1e294]
                      - button "Save comparison" [disabled] [ref=f1e295]
                  - button "Delete dataset" [ref=f1e296] [cursor=pointer]
          - generic [ref=f1e297]:
            - generic [ref=f1e298]:
              - generic [ref=f1e301]: Control Plane
              - generic [ref=f1e302]: healthy
            - generic [ref=f1e303]:
              - generic [ref=f1e304]:
                - generic [ref=f1e305]: API
                - generic [ref=f1e306]: healthy
              - generic [ref=f1e309]:
                - generic [ref=f1e310]: WebSocket
                - generic [ref=f1e311]: Connected
              - generic [ref=f1e312]:
                - generic [ref=f1e313]: WS Endpoint
                - generic [ref=f1e314]: /api/v1/ws
              - generic [ref=f1e315]:
                - generic [ref=f1e316]: Tracked Tests
                - generic [ref=f1e317]: "9"
              - generic [ref=f1e318]:
                - generic [ref=f1e319]: WS Clients
                - generic [ref=f1e320]: "1"
              - generic [ref=f1e321]:
                - generic [ref=f1e322]: Generator Inventory
                - generic [ref=f1e323]: Local mode
              - generic [ref=f1e324]:
                - generic [ref=f1e325]: Execution
                - generic [ref=f1e326]: local
              - generic [ref=f1e327]:
                - generic [ref=f1e328]: Instance
                - generic [ref=f1e329]: Jasons-MacBook-Air-2.local
              - generic [ref=f1e330]:
                - generic [ref=f1e331]: Address
                - generic [ref=f1e332]: 127.0.0.1:18139
              - generic [ref=f1e333]:
                - generic [ref=f1e334]: Versions and build details
                - generic "Component versions and build times" [ref=f1e335]:
                  - generic [ref=f1e336]:
                    - generic [ref=f1e337]: Controller
                    - generic [ref=f1e338]: dev
                    - generic [ref=f1e339]: Built -
                  - generic [ref=f1e340]:
                    - generic [ref=f1e341]: Vite Server
                    - generic [ref=f1e342]: v8.3.4
                    - generic "Oct 20, 2026, 5:35:02 AM EDT" [ref=f1e343]: Built Oct 20, 2026, 5:35:02 AM EDT
                  - generic [ref=f1e344]:
                    - generic [ref=f1e345]: UX
                    - generic [ref=f1e346]: v0.1.0
                    - generic "Oct 20, 2026, 5:35:02 AM EDT" [ref=f1e347]: Built Oct 20, 2026, 5:35:02 AM EDT
          - generic [ref=f1e348]:
            - generic [ref=f1e349]:
              - generic [ref=f1e352]: Recent SLA Threshold Alerts
              - generic [ref=f1e353]: Not configured
            - generic [ref=f1e354]:
              - status [ref=f1e355]: Not configured
              - paragraph [ref=f1e356]: No global SLA policies are enabled. Test-specific quality gates are separate.
              - paragraph [ref=f1e357]: "0 global policies enabled · Last evaluation: None received. History is shared across operators and retained across reloads."
              - generic [ref=f1e358]:
                - link "Configure policies" [ref=f1e359] [cursor=pointer]:
                  - /url: "#/settings?setting=thresholds&returnTo=%23%2Fmonitoring%3FprojectId%3D69582d0c-5700-4931-8f73-e88ee99e09e0%26applicationId%3D5658c321-4f7c-46f9-9969-54a94d45612c%26releaseId%3D80cd2505-2598-442f-906d-98cfe662e48f&projectId=69582d0c-5700-4931-8f73-e88ee99e09e0&applicationId=5658c321-4f7c-46f9-9969-54a94d45612c&releaseId=80cd2505-2598-442f-906d-98cfe662e48f"
                - button "Refresh history" [ref=f1e360] [cursor=pointer]
              - region [ref=f1e361]:
                - heading "Shared SLA incident history" [level=3] [ref=f1e362]
                - generic [ref=f1e363]:
                  - generic [ref=f1e364]:
                    - text: Search incidents
                    - searchbox "Search incidents" [ref=f1e365]
                  - generic [ref=f1e366]:
                    - text: Incident status
                    - combobox "Incident status" [ref=f1e367]:
                      - option "All statuses" [selected]
                      - option "Active"
                      - option "Needs acknowledgement"
                      - option "Acknowledged"
                      - option "Resolved"
                  - generic [ref=f1e368]:
                    - text: Severity
                    - combobox "Severity" [ref=f1e369]:
                      - option "All severities" [selected]
                      - option "Danger"
                      - option "Warning"
                  - generic [ref=f1e370]:
                    - text: Incident timeframe
                    - combobox "Incident timeframe" [ref=f1e371]:
                      - option "All history" [selected]
                      - option "Last 24 hours"
                      - option "Last 7 days"
                      - option "Last 30 days"
                - paragraph [ref=f1e372]: No persisted incidents match these filters.
                - generic [ref=f1e373]:
                  - button "Newer incidents" [disabled] [ref=f1e374]
                  - generic [ref=f1e375]: Page 1
                  - button "Older incidents" [disabled] [ref=f1e376]
      - status [ref=f1e377]:
        - generic [ref=f1e378]: Updated available data 5:38:54 AM
```

# Test source

```ts
  571 |   await left.getByLabel('Source ID', { exact: true }).fill('later unsaved edit')
  572 |   await comparison.getByRole('button', { name: 'Save comparison', exact: true }).click()
  573 |   await expect.poll(() => copied).toBe(true)
  574 |   const downloading = page.waitForEvent('download')
  575 |   await comparison.getByRole('button', { name: 'Export Dataset comparison data as CSV', exact: true }).click()
  576 |   const download = await downloading
  577 |   const csvPath = await download.path()
  578 |   expect(csvPath).not.toBeNull()
  579 |   const csv = await readFile(csvPath!, 'utf8')
  580 |   expect(csv).toContain('Lookup'); expect(csv).toContain('grpc'); expect(csv).toContain('__proto__')
  581 |   expect(csv).not.toContain('later unsaved edit')
  582 |   comparison = await openDataset()
  583 |   await comparison.getByRole('combobox', { name: 'Saved comparison', exact: true }).selectOption('copy')
  584 |   await expect(comparison.getByRole('group', { name: 'Dataset identity filters', exact: true }).getByLabel('Source ID', { exact: true })).toHaveValue('agent-a')
  585 |   await comparison.getByRole('button', { name: 'Analyze comparison', exact: true }).click()
  586 |   await expect.poll(() => analyzed).toBe(2)
  587 |   await page.setViewportSize({ width: 760, height: 1000 })
  588 |   const reopenedLeft = comparison.getByRole('group', { name: 'Dataset identity filters', exact: true })
  589 |   const reopenedRight = comparison.getByRole('group', { name: 'Comparison identity filters', exact: true })
  590 |   await expect(reopenedLeft.getByLabel('Source ID', { exact: true })).toHaveValue('agent-a')
  591 |   await expect(reopenedRight.getByLabel('Source ID', { exact: true })).toHaveValue('agent-b')
  592 |   // Long valid labels must remain editable in this narrow owned container;
  593 |   // unsaved draft additions still cannot alter the executed result or its save.
  594 |   await reopenedLeft.getByRole('button', { name: 'Add dimension filter', exact: true }).click()
  595 |   await reopenedLeft.getByLabel('Filter 4 name', { exact: true }).fill('x'.repeat(128))
  596 |   await reopenedLeft.getByLabel('Filter 4 value', { exact: true }).fill('y'.repeat(128))
  597 |   await captureIdentityFilters(reopenedLeft, test.info().outputPath('imported-identity-comparison-left.png'))
  598 |   await captureIdentityFilters(reopenedRight, test.info().outputPath('imported-identity-comparison-right.png'))
  599 | })
  600 | 
  601 | test('older analytical peers keep v1 imports usable and refuse v2 identity work without downgrade', async ({ page }) => {
  602 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  603 |   const workspace = await createWorkspace(page.context().request)
  604 |   const legacyId = '00000000-0000-0000-0000-000000000021'; const identityId = '00000000-0000-0000-0000-000000000022'
  605 |   const mapping = { version: 1, timestamp: ['ts'], timestamp_encoding: 'unix_s', timezone: 'UTC', measures: [{ value: ['value'], name: 'latency', kind: 'observation', unit: 'ms' }] }
  606 |   let legacyState = 'uploading'; let legacyRevision = 1; let queries = 0; let mutations = 0
  607 |   const records = () => [
  608 |     { id: legacyId, project_id: workspace.projectId, name: 'Legacy measurements', state: legacyState, revision: legacyRevision, files: [{ id: 'file', relative_path: 'legacy.parquet', uploaded: 16, size: 16 }], mapping, accepted: 1, rejected: 0 },
  609 |     { id: identityId, project_id: workspace.projectId, name: 'Retained identity measurements', state: 'ready', revision: 1, files: [], mapping: { ...mapping, version: 2, identity: { source: ['source'] } }, accepted: 1, rejected: 0 },
  610 |   ]
  611 |   await page.route('**/api/v1/analysis/**', async route => {
  612 |     const request = route.request(); const path = new URL(request.url()).pathname
  613 |     const send = (value: unknown) => route.fulfill({ json: value })
  614 |     if (path.endsWith('/capabilities')) return send({ native_parquet: true, enabled: true, chunk_bytes: 4 * 1024 * 1024 })
  615 |     if (path.endsWith('/imports')) return send(records())
  616 |     if (path.endsWith('/mappings') || path.endsWith('/comparisons')) return send([])
  617 |     if (path.endsWith('/preview')) return send({ schema: { rows: 1, columns: [{ path: 'ts', path_components: ['ts'], physical_type: 'INT64', repeated: false }, { path: 'value', path_components: ['value'], physical_type: 'DOUBLE', repeated: false }] }, samples: [] })
  618 |     if (path.endsWith('/mapping')) { expect(request.postDataJSON().mapping).toEqual(mapping); legacyRevision++; mutations++; return send({ ...records()[0], state: 'mapped' }) }
  619 |     if (path.endsWith('/commit')) { legacyState = 'ready'; legacyRevision++; mutations++; return send(records()[0]) }
  620 |     if (path.endsWith('/series')) { expect(path).toContain(legacyId); expect(request.postDataJSON()).not.toHaveProperty('source_id'); queries++; return send({ points: [] }) }
  621 |     return route.fulfill({ status: 404, json: { error: 'unexpected old-peer operation' } })
  622 |   })
  623 |   await page.goto(`/#/monitoring?${scopeQuery(workspace)}`); await page.reload()
  624 |   const area = page.getByRole('region', { name: 'Analysis workspace', exact: true })
  625 |   await area.getByRole('button', { name: 'Legacy measurements · uploading', exact: true }).click()
  626 |   await expect(area.getByRole('group', { name: 'Imported measurement identities', exact: true })).toHaveCount(0)
  627 |   await expect(area).toContainText('Version 1 imports remain available')
  628 |   await area.getByRole('button', { name: 'Validate and import', exact: true }).click()
  629 |   await expect(area).toContainText('State: ready')
  630 |   const query = area.getByRole('group', { name: 'Query dataset', exact: true })
  631 |   await query.getByLabel('From (UTC)', { exact: true }).fill('2026-01-01T00:00')
  632 |   await query.getByLabel('To (UTC)', { exact: true }).fill('2026-01-01T00:01')
  633 |   await query.getByRole('button', { name: 'Show series', exact: true }).click()
  634 |   await expect.poll(() => queries).toBe(1)
  635 |   await area.getByRole('button', { name: 'Retained identity measurements · ready', exact: true }).click()
  636 |   await expect(query).toContainText('This dataset requires imported identity schema 2')
  637 |   await expect(query.getByRole('button', { name: 'Show series', exact: true })).toBeDisabled()
  638 |   await expect(area.getByRole('region', { name: 'Dataset comparison', exact: true })).toContainText('stored selectors remain unchanged')
  639 |   await expect(area.getByRole('button', { name: 'Analyze comparison', exact: true })).toBeDisabled()
  640 |   expect(queries).toBe(1); expect(mutations).toBe(2)
  641 |   expect(records()[1].mapping.version).toBe(2)
  642 | })
  643 | 
  644 | 
  645 | for (const peer of ['missing-capability', 'missing-mapping', 'current', 'legacy-handler', 'bad-echo'] as const) {
  646 |   test(`mapping reassociation preserves declared measurements with ${peer}`, async ({ page }) => {
  647 |     if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  648 |     const workspace = await createWorkspace(page.context().request)
  649 |     const mapping = { version: 2, timestamp: ['ts'], timestamp_encoding: 'unix_s', timezone: 'UTC', measures: [{ value: ['value'], name: 'latency', kind: 'summary', unit: 'ms', statistic: 'p95', window_seconds: 60 }] }
  650 |     const dataset = { id: '00000000-0000-0000-0000-000000000031', project_id: workspace.projectId, name: 'Declared measurements', state: 'ready', revision: 4, files: [], mapping: peer === 'missing-mapping' ? undefined : mapping, accepted: 2, rejected: 0 }
  651 |     let requests = 0
  652 |     await page.route('**/api/v1/analysis/**', async route => {
  653 |       const request = route.request(); const path = new URL(request.url()).pathname
  654 |       const send = (value: unknown) => route.fulfill({ json: value })
  655 |       if (path.endsWith('/capabilities')) return send({ native_parquet: true, enabled: true, imported_identity_version: 2, mapping_association_version: peer === 'missing-capability' ? undefined : 1, chunk_bytes: 4 * 1024 * 1024, summary_statistics: ['p95'] })
  656 |       if (path.endsWith('/imports')) return send([dataset])
  657 |       if (path.endsWith('/mappings') || path.endsWith('/comparisons')) return send([])
  658 |       if (path.endsWith('/association')) {
  659 |         expect(request.method()).toBe('PATCH')
  660 |         expect(request.postDataJSON()).toEqual({ contract_version: 1, run_id: 'reviewed-run', revision: 4 })
  661 |         requests++
  662 |         if (peer === 'legacy-handler') return route.fulfill({ status: 405, json: { error: 'method not allowed' } })
  663 |         return send({ contract_version: 1, import: { ...dataset, revision: 5, run_id: 'reviewed-run', mapping: peer === 'bad-echo' ? undefined : mapping } })
  664 |       }
  665 |       return route.fulfill({ status: 404, json: { error: 'unexpected reassociation workflow operation' } })
  666 |     })
  667 |     await page.goto(`/#/monitoring?${scopeQuery(workspace)}`); await page.reload()
  668 |     const area = page.getByRole('region', { name: 'Analysis workspace', exact: true })
  669 |     await area.getByRole('button', { name: 'Declared measurements · ready', exact: true }).click()
  670 |     const comparison = area.getByRole('region', { name: 'Dataset comparison', exact: true })
> 671 |     await comparison.getByLabel('Compare with', { exact: true }).selectOption('run')
      |                                                                  ^ TimeoutError: locator.selectOption: Timeout 15000ms exceeded.
  672 |     await comparison.getByLabel('Run ID', { exact: true }).fill('reviewed-run')
  673 |     const associate = comparison.getByRole('button', { name: 'Associate with run', exact: true })
  674 |     if (peer === 'missing-capability' || peer === 'missing-mapping') {
  675 |       await expect(associate).toBeDisabled()
  676 |       await expect(comparison).toContainText(peer === 'missing-mapping' ? 'Mapping details are unavailable' : 'cannot safely reassociate')
  677 |       expect(requests).toBe(0)
  678 |     } else {
  679 |       await associate.click()
  680 |       await expect.poll(() => requests).toBe(1)
  681 |       if (peer === 'current') await expect(comparison).toContainText('Associated with run reviewed-run')
  682 |       else {
  683 |         await expect(comparison).not.toContainText('Associated with run reviewed-run')
  684 |         await expect(comparison.getByRole('alert')).toContainText(peer === 'bad-echo' ? 'did not confirm the mapping-preserving association' : 'method not allowed')
  685 |       }
  686 |     }
  687 |     expect(dataset.mapping).toEqual(peer === 'missing-mapping' ? undefined : mapping)
  688 |   })
  689 | }
  690 | 
```