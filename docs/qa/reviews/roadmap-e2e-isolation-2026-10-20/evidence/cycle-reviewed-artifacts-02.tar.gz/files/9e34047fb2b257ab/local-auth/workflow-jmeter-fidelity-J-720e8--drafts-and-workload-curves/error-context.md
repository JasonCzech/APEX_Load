# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-jmeter-fidelity.spec.ts >> JMeter messaging preview preserves three blocked drafts and workload curves
- Location: e2e/workflow-jmeter-fidelity.spec.ts:101:1

# Error details

```
Error: {"error":"Batch publication failed; retry the same operation"}


expect(received).toBeTruthy()

Received: false
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to main content" [ref=f2e4] [cursor=pointer]:
    - /url: "#app-main"
  - complementary [ref=f2e6] [cursor=pointer]:
    - button "APEX Load dashboard" [ref=f2e7]:
      - img "APEX Load" [ref=f2e8]
    - button "Workspace context. e2e-1792519422250-206545 domain / e2e-1792519422250-206545 project / e2e-1792519422250-206545 application / e2e-1792519422250-206545 1.0" [ref=f2e15]:
      - generic [aria-hidden] [ref=f2e16]: ◈
    - navigation "Primary navigation" [ref=f2e17]:
      - button "New run" [ref=f2e19]
      - generic [ref=f2e24]:
        - button "Dashboard" [ref=f2e26]
        - button "Command Center" [ref=f2e34]
        - button "Results" [ref=f2e41]
        - button "Monitoring" [ref=f2e45]
        - button "Activity" [ref=f2e50]
      - generic [ref=f2e54]:
        - button "Scripts" [ref=f2e56]
        - button "Scenarios" [ref=f2e62]
        - button "Shared assets" [ref=f2e67]
      - generic [ref=f2e73]:
        - button "Repository" [ref=f2e75]
        - button "Access" [ref=f2e81]
        - button "Settings" [ref=f2e88]
      - button "Help & documentation" [ref=f2e95]
    - generic [ref=f2e100]:
      - generic [ref=f2e101]:
        - button "Local System Administrator. System Admin. Open account details" [ref=f2e103]:
          - generic [aria-hidden] [ref=f2e104]: LS
        - generic [ref=f2e105]:
          - 'status "Live connection: Live" [ref=f2e106]':
            - generic [ref=f2e108]:
              - generic [ref=f2e109]: "Live connection:"
              - text: Live
          - 'button "Build info: local · dev" [ref=f2e111]'
      - button "Expand sidebar" [ref=f2e114]
  - main [ref=f2e117]:
    - status [ref=f2e118]: Import JMeter Test Plan
    - generic "Dashboard controls" [ref=f2e119]:
      - heading "Import JMeter Test Plan" [level=1] [ref=f2e121]
      - generic [ref=f2e122]:
        - link "Help for this page" [ref=f2e123] [cursor=pointer]:
          - /url: "#/docs?guide=user-guide&article=imports"
        - generic "Deployment identity" [ref=f2e124]:
          - generic "You are using APEX Load in a web browser; tests run on the Server controller." [ref=f2e125]:
            - text: Web app · Server
            - generic [ref=f2e127]: . You are using APEX Load in a web browser; tests run on the Server controller.
        - combobox "Dashboard color theme" [ref=f2e129] [cursor=pointer]:
          - option "System (Auto)"
          - option "Dark Theme"
          - option "Light Theme" [selected]
          - option "Solarized Dark"
          - option "Solarized Light"
          - option "Monokai Dimmed"
    - group "Script import controls" [ref=f2e131]:
      - generic [ref=f2e132]:
        - generic [ref=f2e133]:
          - generic [ref=f2e134]:
            - heading "JMeter Test Plan" [level=2] [ref=f2e135]
            - paragraph [ref=f2e136]:
              - text: Upload a
              - code [ref=f2e137]: .jmx
              - text: plan, a ZIP containing multiple JMX plans, or a LoadRunner Enterprise JMeter
              - code [ref=f2e138]: .usz
              - text: and convert their thread groups into APEX Load reusable scripts. The importer preserves variables, CSV data sources, headers, timers, and review notes where possible.
          - button "Back" [ref=f2e139] [cursor=pointer]
        - generic [ref=f2e140]:
          - list "Import workflow" [ref=f2e141]:
            - listitem [ref=f2e142]:
              - generic [aria-hidden] [ref=f2e143]: "1."
              - text: Provide source
            - listitem [ref=f2e144]:
              - generic [aria-hidden] [ref=f2e145]: "2."
              - text: Review and resolve
            - listitem [ref=f2e146]:
              - generic [aria-hidden] [ref=f2e147]: "3."
              - text: Save scripts
            - listitem [ref=f2e148]:
              - generic [aria-hidden] [ref=f2e149]: "4."
              - text: Debug one iteration
          - paragraph [ref=f2e150]: Review the generated output before saving. Import checks do not run your script; debug it against a controlled target after saving.
        - group [ref=f2e151]:
          - generic "Source & conversion options — changing these requires a new review" [ref=f2e152] [cursor=pointer]
          - option "Require review for ambiguous timestamps" [selected]
          - option "Normalize to UTC with milliseconds"
          - option "Preserve wall clock and acknowledge literal Z suffix"
        - generic [ref=f2e153]: Conversion complete. Review the generated scripts, warnings, and assumptions before saving.
        - button "Import Coverage" [ref=f2e155] [cursor=pointer]
        - generic [ref=f2e156]:
          - region "Reviewed JMeter batch repairs" [ref=f2e157]:
            - heading "Reviewed repairs for all scripts" [level=4] [ref=f2e158]
            - paragraph [ref=f2e159]: Preview and apply a revision of the complete import. Remaining execution blockers stay enforced.
            - group [ref=f2e160]:
              - generic [ref=f2e161]:
                - text: Repair
                - combobox "Repair" [ref=f2e162]:
                  - option "Confirm UTC and no property overrides" [selected]
                  - option "Normalize Kafka OAuth option names"
                  - option "Bind Kafka credential references"
                  - option "Bind Event Hubs credential reference"
                  - option "Replace a payload timestamp with UTC"
                  - option "Add an Event Hubs application property"
                  - option "Parameterize a payload field"
              - generic [ref=f2e163]:
                - checkbox "Use UTC and confirm there were no JMeter property overrides" [checked] [ref=f2e164] [cursor=pointer]
                - text: Use UTC and confirm there were no JMeter property overrides
              - button "Preview batch repair" [ref=f2e165] [cursor=pointer]
              - button "Apply reviewed batch repair" [ref=f2e166] [cursor=pointer]
            - alert [ref=f2e167]: Batch publication failed; retry the same operation
            - generic "Batch repair comparison" [ref=f2e168]:
              - group [ref=f2e169]:
                - generic "Kafka_payments_1 — Changed" [ref=f2e170]
              - group [ref=f2e171]:
                - generic "Event_Hubs_east_2 — Changed" [ref=f2e172]
              - group [ref=f2e173]:
                - generic "Event_Hubs_west_3 — Changed" [ref=f2e174]
              - group [ref=f2e175]:
                - generic "Scenario and remaining blockers" [ref=f2e176]
          - generic [ref=f2e177]:
            - tablist "Import review sections" [ref=f2e178]:
              - tab "Review, 11 review items" [selected] [ref=f2e179] [cursor=pointer]:
                - text: Review
                - generic [aria-hidden] [ref=f2e180]: "11"
              - tab "Credentials, 5 review items" [ref=f2e181] [cursor=pointer]:
                - text: Credentials
                - generic [aria-hidden] [ref=f2e182]: "5"
              - tab "Data & parameters" [ref=f2e183] [cursor=pointer]
              - tab "Runtime settings" [ref=f2e184] [cursor=pointer]
              - tab "DSL Preview" [ref=f2e185] [cursor=pointer]
              - tab "Source Mapping" [ref=f2e186] [cursor=pointer]
            - tabpanel "Review, 11 review items" [ref=f2e187]:
              - generic [ref=f2e188]:
                - generic [ref=f2e189]:
                  - status [ref=f2e190]: Import review has blockers. Resolve them before replay.
                  - generic [ref=f2e191]:
                    - heading "Conversion Review" [level=3] [ref=f2e192]
                    - group [ref=f2e193]:
                      - generic "Save & editor behavior" [ref=f2e194]
                  - button "Save 3 drafts" [ref=f2e196] [cursor=pointer]
                - region [ref=f2e198]:
                  - generic [ref=f2e199]:
                    - generic [ref=f2e200]:
                      - heading "Save destination" [level=3] [ref=f2e201]
                      - paragraph [ref=f2e202]: Choose where the imported scripts will appear in this project.
                    - generic [ref=f2e203]:
                      - generic [ref=f2e204]: Destination folder
                      - combobox "Destination folder for saved scripts" [ref=f2e205]:
                        - option "Project root" [selected]
                  - status [ref=f2e206]: No script folders exist in this project yet. Imports will save to Project root, or create a folder below.
                  - generic [ref=f2e207]:
                    - generic [ref=f2e208]:
                      - generic [ref=f2e209]: New script folder name
                      - textbox "New script folder name" [ref=f2e210]:
                        - /placeholder: Imported API scripts
                        - text: messaging original
                    - button "Create and select folder" [ref=f2e211] [cursor=pointer]
                - status [ref=f2e212]: This import review expires at Oct 20, 2026, 2:33 PM EDT (in 30 min).
                - status [ref=f2e213]:
                  - generic "JMeter review summary" [ref=f2e214]: 11 blocking behaviors · 0 behaviors requiring review · 0 unsupported behaviors · 8 warnings · 0 informational findings
                  - button [ref=f2e215] [cursor=pointer]:
                    - strong [ref=f2e216]: "4"
                    - text: credential bindings to configure
                  - button [ref=f2e217] [cursor=pointer]:
                    - strong [ref=f2e218]: "1"
                    - text: preserved credential to review
                - region "Resolve import issues" [ref=f2e220]:
                  - generic [ref=f2e221]:
                    - generic [ref=f2e222]:
                      - heading "Resolve import issues" [level=3] [ref=f2e223]
                      - paragraph [ref=f2e224]: 19 findings · 11 blocking · 8 warnings · 0 notes. Informational findings do not block replay.
                    - button "Next unresolved issue" [ref=f2e226] [cursor=pointer]
                  - generic [ref=f2e227]:
                    - generic [ref=f2e228]:
                      - text: Find an issue
                      - searchbox "Find an issue" [ref=f2e229]
                    - generic [ref=f2e230]:
                      - text: Show
                      - combobox "Show" [ref=f2e231]:
                        - option "All findings (19)" [selected]
                        - option "Blockers"
                        - option "Errors"
                        - option "Warnings"
                        - option "Review notes"
                        - option "Reviewed (0)"
                    - status [ref=f2e232]: 19 matching findings
                  - generic [ref=f2e233]:
                    - generic "Import issue queue" [ref=f2e234]:
                      - heading "Credentials 3 issues" [level=5] [ref=f2e235]:
                        - text: Credentials
                        - generic [ref=f2e236]: 3 issues
                      - button "Blocker Eventhubs credentials required in fixture-242 1 occurrence" [pressed] [ref=f2e237] [cursor=pointer]:
                        - generic [ref=f2e238]: Blocker
                        - generic [ref=f2e239]:
                          - strong [ref=f2e240]: Eventhubs credentials required in fixture-242
                          - generic [ref=f2e241]: 1 occurrence
                      - button "Blocker Eventhubs credentials required in fixture-301 1 occurrence" [ref=f2e242] [cursor=pointer]:
                        - generic [ref=f2e243]: Blocker
                        - generic [ref=f2e244]:
                          - strong [ref=f2e245]: Eventhubs credentials required in fixture-301
                          - generic [ref=f2e246]: 1 occurrence
                      - button "Blocker Kafka oauth credentials required in fixture-197 1 occurrence" [ref=f2e247] [cursor=pointer]:
                        - generic [ref=f2e248]: Blocker
                        - generic [ref=f2e249]:
                          - strong [ref=f2e250]: Kafka oauth credentials required in fixture-197
                          - generic [ref=f2e251]: 1 occurrence
                      - heading "Data and parameters 1 issue" [level=5] [ref=f2e252]:
                        - text: Data and parameters
                        - generic [ref=f2e253]: 1 issue
                      - button "Warning Source warning 1 occurrence" [ref=f2e254] [cursor=pointer]:
                        - generic [ref=f2e255]: Warning
                        - generic [ref=f2e256]:
                          - strong [ref=f2e257]: Source warning
                          - generic [ref=f2e258]: 1 occurrence
                      - heading "Runtime settings 1 issue" [level=5] [ref=f2e259]:
                        - text: Runtime settings
                        - generic [ref=f2e260]: 1 issue
                      - button "Warning Source warning 1 occurrence" [ref=f2e261] [cursor=pointer]:
                        - generic [ref=f2e262]: Warning
                        - generic [ref=f2e263]:
                          - strong [ref=f2e264]: Source warning
                          - generic [ref=f2e265]: 1 occurrence
                      - heading "Source mapping 5 issues" [level=5] [ref=f2e266]:
                        - text: Source mapping
                        - generic [ref=f2e267]: 5 issues
                      - button "Warning Source warning 1 occurrence" [ref=f2e268] [cursor=pointer]:
                        - generic [ref=f2e269]: Warning
                        - generic [ref=f2e270]:
                          - strong [ref=f2e271]: Source warning
                          - generic [ref=f2e272]: 1 occurrence
                      - button "Warning Source warning 1 occurrence" [ref=f2e273] [cursor=pointer]:
                        - generic [ref=f2e274]: Warning
                        - generic [ref=f2e275]:
                          - strong [ref=f2e276]: Source warning
                          - generic [ref=f2e277]: 1 occurrence
                      - button "Warning Source warning 1 occurrence" [ref=f2e278] [cursor=pointer]:
                        - generic [ref=f2e279]: Warning
                        - generic [ref=f2e280]:
                          - strong [ref=f2e281]: Source warning
                          - generic [ref=f2e282]: 1 occurrence
                      - button "Warning Source warning 1 occurrence" [ref=f2e283] [cursor=pointer]:
                        - generic [ref=f2e284]: Warning
                        - generic [ref=f2e285]:
                          - strong [ref=f2e286]: Source warning
                          - generic [ref=f2e287]: 1 occurrence
                      - button "Warning Source warning 1 occurrence" [ref=f2e288] [cursor=pointer]:
                        - generic [ref=f2e289]: Warning
                        - generic [ref=f2e290]:
                          - strong [ref=f2e291]: Source warning
                          - generic [ref=f2e292]: 1 occurrence
                      - heading "Conversion findings 9 issues" [level=5] [ref=f2e293]:
                        - text: Conversion findings
                        - generic [ref=f2e294]: 9 issues
                      - button "Blocker Kafka batch allocation parity unverified in fixture-197 1 occurrence" [ref=f2e295] [cursor=pointer]:
                        - generic [ref=f2e296]: Blocker
                        - generic [ref=f2e297]:
                          - strong [ref=f2e298]: Kafka batch allocation parity unverified in fixture-197
                          - generic [ref=f2e299]: 1 occurrence
                      - button "Blocker Kafka nonstandard oauth options in fixture-197 1 occurrence" [ref=f2e300] [cursor=pointer]:
                        - generic [ref=f2e301]: Blocker
                        - generic [ref=f2e302]:
                          - strong [ref=f2e303]: Kafka nonstandard oauth options in fixture-197
                          - generic [ref=f2e304]: 1 occurrence
                      - button "Blocker Messaging compatibility unverified in fixture-197 1 occurrence" [ref=f2e305] [cursor=pointer]:
                        - generic [ref=f2e306]: Blocker
                        - generic [ref=f2e307]:
                          - strong [ref=f2e308]: Messaging compatibility unverified in fixture-197
                          - generic [ref=f2e309]: 1 occurrence
                      - button "Blocker Messaging compatibility unverified in fixture-242 1 occurrence" [ref=f2e310] [cursor=pointer]:
                        - generic [ref=f2e311]: Blocker
                        - generic [ref=f2e312]:
                          - strong [ref=f2e313]: Messaging compatibility unverified in fixture-242
                          - generic [ref=f2e314]: 1 occurrence
                      - button "Blocker Messaging compatibility unverified in fixture-301 1 occurrence" [ref=f2e315] [cursor=pointer]:
                        - generic [ref=f2e316]: Blocker
                        - generic [ref=f2e317]:
                          - strong [ref=f2e318]: Messaging compatibility unverified in fixture-301
                          - generic [ref=f2e319]: 1 occurrence
                      - button "Blocker Reference context confirmation required in fixture-197 1 occurrence" [ref=f2e320] [cursor=pointer]:
                        - generic [ref=f2e321]: Blocker
                        - generic [ref=f2e322]:
                          - strong [ref=f2e323]: Reference context confirmation required in fixture-197
                          - generic [ref=f2e324]: 1 occurrence
                      - button "Blocker Reference context confirmation required in fixture-242 1 occurrence" [ref=f2e325] [cursor=pointer]:
                        - generic [ref=f2e326]: Blocker
                        - generic [ref=f2e327]:
                          - strong [ref=f2e328]: Reference context confirmation required in fixture-242
                          - generic [ref=f2e329]: 1 occurrence
                      - button "Blocker Reference context confirmation required in fixture-301 1 occurrence" [ref=f2e330] [cursor=pointer]:
                        - generic [ref=f2e331]: Blocker
                        - generic [ref=f2e332]:
                          - strong [ref=f2e333]: Reference context confirmation required in fixture-301
                          - generic [ref=f2e334]: 1 occurrence
                      - button "Warning JMeter HeaderManager 1 occurrence" [ref=f2e335] [cursor=pointer]:
                        - generic [ref=f2e336]: Warning
                        - generic [ref=f2e337]:
                          - strong [ref=f2e338]: JMeter HeaderManager
                          - generic [ref=f2e339]: 1 occurrence
                    - article "Selected issue" [ref=f2e340]:
                      - generic [ref=f2e342]:
                        - heading "Eventhubs credentials required in fixture-242" [level=4] [ref=f2e343]
                        - paragraph [ref=f2e344]: 1 affected location
                      - generic "Issue actions" [ref=f2e345]:
                        - button "Review credentials" [ref=f2e346] [cursor=pointer]
                        - button "Open related source" [ref=f2e347] [cursor=pointer]
                      - region "Problem and impact" [ref=f2e348]:
                        - heading "Why this matters" [level=5] [ref=f2e349]
                        - paragraph [ref=f2e350]: "Resolve imported behavior before replay: jmeter_eventhubs_credentials_required"
                      - region "Available resolution" [ref=f2e351]:
                        - heading "Available resolution" [level=5] [ref=f2e352]
                        - paragraph [ref=f2e353]: Review credential handling in Credentials, then verify the affected request before replay.
                      - group [ref=f2e354]:
                        - generic "Technical evidence and affected locations (1)" [ref=f2e355] [cursor=pointer]
                - generic [ref=f2e356]:
                  - generic [ref=f2e357]:
                    - heading "Assumptions" [level=4] [ref=f2e358]
                    - list [ref=f2e359]:
                      - listitem [ref=f2e360]: JMeter controller structure was flattened into script action order where safe.
                  - generic [ref=f2e361]:
                    - generic [ref=f2e362]:
                      - heading "Generated Assets" [level=4] [ref=f2e363]
                      - generic [ref=f2e364]: messaging_original.jmx
                    - generic [ref=f2e365]:
                      - generic [ref=f2e366]:
                        - generic [ref=f2e367]: Script
                        - strong [ref=f2e368]: Kafka_payments_1
                        - generic [ref=f2e369]: 1 actions / 0 data sources / 0 extractors
                      - generic [ref=f2e370]:
                        - generic [ref=f2e371]: Script
                        - strong [ref=f2e372]: Event_Hubs_east_2
                        - generic [ref=f2e373]: 1 actions / 0 data sources / 0 extractors
                      - generic [ref=f2e374]:
                        - generic [ref=f2e375]: Script
                        - strong [ref=f2e376]: Event_Hubs_west_3
                        - generic [ref=f2e377]: 1 actions / 0 data sources / 0 extractors
                      - generic [ref=f2e378]:
                        - generic [ref=f2e379]: Scenario Draft
                        - strong [ref=f2e380]: 3 groups
                        - generic [ref=f2e381]: 1h5m0s
                  - region "Messaging fidelity" [ref=f2e382]:
                    - heading "Messaging fidelity" [level=4] [ref=f2e383]
                    - paragraph [ref=f2e384]:
                      - strong [ref=f2e385]: Converted drafts · replay blocked
                    - paragraph [ref=f2e386]: 3/3 enabled workload samplers mapped. 3 blocked; 2 disabled workload samplers remain disabled.
                    - paragraph [ref=f2e387]: "Single generator required. Strict compatibility is unverified. Reference target: JMeter 5.4.1, JDK 17, Kafka 3.3.1, DI-KafkaMeter 8c2dcc9, PNOP Event Hubs 0.2.8, Throughput Shaping Timer 2.6."
                    - paragraph [ref=f2e388]: Source timezone and property overrides require confirmation. Credentials and source defects remain execution blockers after warning acknowledgement.
                    - paragraph [ref=f2e389]: "Duration: 3,900 seconds. Approximately 630,450 planned samples, assuming one message per sampler, sufficient available threads, and no property overrides."
                    - 'figure "Kafka payments: 100 threads · 1s thread ramp · peak 84 samples/s" [ref=f2e390]':
                      - img "Kafka payments throughput schedule" [ref=f2e392]:
                        - generic [ref=f2e395]: 0 s
                        - generic [ref=f2e396]: 3900 s
                    - 'figure "Event Hubs east: 50 threads · 1s thread ramp · peak 42 samples/s" [ref=f2e397]':
                      - img "Event Hubs east throughput schedule" [ref=f2e399]:
                        - generic [ref=f2e402]: 0 s
                        - generic [ref=f2e403]: 3900 s
                    - 'figure "Event Hubs west: 50 threads · 1s thread ramp · peak 42 samples/s" [ref=f2e404]':
                      - img "Event Hubs west throughput schedule" [ref=f2e406]:
                        - generic [ref=f2e409]: 0 s
                        - generic [ref=f2e410]: 3900 s
                    - group [ref=f2e411]:
                      - 'generic "Kafka_payments_1: source and effective Kafka settings" [ref=f2e412]'
                      - paragraph [ref=f2e413]: These settings are preserved for review. Unsupported client behavior remains blocked.
                      - generic [ref=f2e414]: "[ { \"base_settings\": { \"batch.size\": \"9999999\", \"bootstrap.servers\": \"broker.fixture.test:9092\", \"client.id\": \"\", \"key.serializer\": \"org.apache.kafka.common.serialization.StringSerializer\", \"security.protocol\": \"plaintext\", \"value.serializer\": \"org.apache.kafka.common.serialization.StringSerializer\" }, \"effective_settings\": { \"acks\": \"all\", \"batch.size\": \"16384\", \"bootstrap.servers\": \"broker.fixture.test:9092\", \"buffer.memory\": \"33554432\", \"client.id\": \"\", \"enable.idempotence\": \"false\", \"key.serializer\": \"org.apache.kafka.common.serialization.StringSerializer\", \"linger.ms\": \"1\", \"max.block.ms\": \"30000\", \"retries\": \"1\", \"sasl.jaas.config\": \"[credential options withheld]\", \"sasl.login.callback.handler.class\": \"org.apache.kafka.common.security.oauthbearer.secured.OAuthBearerLoginCallbackHandler\", \"sasl.mechanism\": \"OAUTHBEARER\", \"sasl.oauthbearer.token.endpoint.url\": \"[REDACTED]\", \"security.protocol\": \"SASL_SSL\", \"ssl.enabled.protocols\": \"TLSv1.2\", \"value.serializer\": \"org.apache.kafka.common.serialization.StringSerializer\" }, \"ignored_producer_settings\": [ \"group\", \"heartbeat.interval.ms\", \"session.timeout.ms\" ], \"native_config\": { \"acks\": \"all\", \"brokers\": [ \"broker.fixture.test:9092\" ], \"idempotence\": \"disabled\", \"oauth\": { \"authentication_method\": \"kafka_3_3_1_basic\", \"client_id\": \"{{secret.JMETER_KAFKA_PAYMENTS_1_KAFKA_CLIENTID}}\", \"client_secret_ref\": \"{{secret.JMETER_KAFKA_PAYMENTS_1_KAFKA_CLIENTSECRET}}\", \"mode\": \"client_credentials\", \"scope\": \"00000000-0000-0000-0000-000000000001/.default\", \"token_url\": \"[REDACTED]\" }, \"partition_strategy\": \"explicit\", \"producer\": { \"admission_timeout_ms\": 30000, \"buffer_bytes\": 33554432, \"delivery_timeout_ms\": 120000, \"linger_ms\": 1, \"request_timeout_ms\": 30000, \"retries\": 1 }, \"sasl_mechanism\": \"oauthbearer\", \"security_protocol\": \"sasl_ssl\", \"tls\": { \"max_version\": \"1.2\", \"min_version\": \"1.2\" }, \"topic\": \"fixture.events\" }, \"oauth_source\": { \"credentials\": \"[REDACTED]\", \"option_names\": [ \"cid\", \"cs\", \"scope\" ], \"scope\": \"00000000-0000-0000-0000-000000000001/.default\" }, \"producer_lifecycle\": \"source_engine\", \"producer_variable\": \"KafkaProducerClient\", \"sample_timing\": \"send_acknowledgement\", \"source_node_id\": \"jmx:843dde9a1a6109cc2b71c35af69434e5c8bace7eb8158f75e2b05e97f168ef98:8657:com.di.jmeter.kafka.config.KafkaProducerConfig\" } ]"
                  - group [ref=f2e415]:
                    - generic "Conversion reference" [ref=f2e416] [cursor=pointer]
```

# Test source

```ts
  43  |     response.request().method() === 'POST'
  44  |     && new URL(response.url()).pathname === '/api/v1/domains'
  45  |   ))
  46  |   await page.getByRole('button', { name: 'Add domain' }).click()
  47  |   const domainPayload = await (await domainResponsePromise).json()
  48  |   const domainId = responseID(domainPayload, 'create domain', 'domain')
  49  |   responseID(domainPayload, 'provision application repository', 'application_repository')
  50  |   const categoryId = responseID(domainPayload, 'default category', 'default_category')
  51  | 
  52  |   await expect(page.getByText(`Domain "${domainName}" created.`)).toBeVisible({ timeout: 15_000 })
  53  |   await expect(page.locator('button.settings-app-card').filter({ hasText: domainName })).toBeVisible()
  54  | 
  55  |   const settingsSections = page.getByRole('navigation', { name: 'Settings sections' })
  56  |   await settingsSections.getByRole('button', { name: 'Projects', exact: true }).click()
  57  |   const projectNameInput = page.getByPlaceholder('Create project, e.g. Customer Portal')
  58  | 
  59  |   const createProject = async (name: string) => {
  60  |     await projectNameInput.fill(name)
  61  |     const responsePromise = page.waitForResponse(response => (
  62  |       response.request().method() === 'POST'
  63  |       && new URL(response.url()).pathname === '/api/v1/projects'
  64  |     ))
  65  |     await page.getByRole('button', { name: 'Add Project' }).click()
  66  |     const payload = await (await responsePromise).json()
  67  |     const project = record(payload, 'project')
  68  |     expect(project.domain_id, `${name} must be created in the UI-selected domain`).toBe(domainId)
  69  |     await expect(page.locator('button.settings-app-card').filter({ hasText: name })).toBeVisible({ timeout: 15_000 })
  70  |     return responseID(payload, `create project ${name}`, 'project')
  71  |   }
  72  | 
  73  |   const ownerProjectId = await createProject(ownerProjectName)
  74  |   const decoyProjectId = await createProject(decoyProjectName)
  75  |   expect(routeScope(page.url()).get('projectId')).toBe(decoyProjectId)
  76  | 
  77  |   // Keep the decoy as the active workspace project, then explicitly target the
  78  |   // owner in the application picker. This is the wrong-project regression:
  79  |   // the picker must move real workspace scope, not only its local form cursor.
  80  |   await settingsSections.getByRole('button', { name: 'Applications & releases' }).click()
  81  |   await page.getByPlaceholder('Create application, e.g. ACC').fill(applicationName)
  82  |   const applicationProject = page.getByRole('combobox', { name: 'Project for the new application' })
  83  |   await applicationProject.selectOption(ownerProjectId)
  84  |   await expect(applicationProject).toHaveValue(ownerProjectId)
  85  | 
  86  |   const applicationResponsePromise = page.waitForResponse(response => (
  87  |     response.request().method() === 'POST'
  88  |     && new URL(response.url()).pathname === '/api/v1/applications'
  89  |   ))
  90  |   await page.getByRole('button', { name: 'Add Application' }).click()
  91  |   const applicationPayload = await (await applicationResponsePromise).json()
  92  |   const application = record(applicationPayload, 'application')
  93  |   const applicationId = responseID(applicationPayload, 'create application', 'application')
  94  |   expect(application.project_id, 'application must belong to the project chosen in the UI').toBe(ownerProjectId)
  95  | 
  96  |   await expect(page.locator('button.settings-app-card').filter({ hasText: applicationName })).toBeVisible({ timeout: 15_000 })
  97  |   await expect(page.getByRole('button', { name: new RegExp(`Workspace context\\..*${ownerProjectName}`) })).toBeVisible()
  98  |   await expect.poll(() => routeScope(page.url()).get('projectId')).toBe(ownerProjectId)
  99  |   await expect.poll(() => routeScope(page.url()).get('applicationId')).toBe(applicationId)
  100 | 
  101 |   const storedApplication = await request.get(`/api/v1/applications/${applicationId}`)
  102 |   expect(storedApplication.ok()).toBeTruthy()
  103 |   expect(record(await storedApplication.json(), 'application').project_id).toBe(ownerProjectId)
  104 | 
  105 |   // Release creation in the sidebar changes active scope. The repository tabs
  106 |   // below then prove that the same hierarchy is visible on the S2 route.
  107 |   await page.getByRole('button', { name: /^Workspace context\./ }).click()
  108 |   await page.getByRole('button', { name: /Select release\. Current release:/ }).click()
  109 |   await page.getByRole('button', { name: 'New Release' }).click()
  110 |   const releaseDialog = page.getByRole('dialog', { name: 'New Release' })
  111 |   await releaseDialog.getByRole('textbox', { name: 'Name' }).fill(releaseName)
  112 |   const releaseResponsePromise = page.waitForResponse(response => (
  113 |     response.request().method() === 'POST'
  114 |     && new URL(response.url()).pathname === `/api/v1/projects/${ownerProjectId}/releases`
  115 |   ))
  116 |   await releaseDialog.getByRole('button', { name: 'Create release' }).click()
  117 |   const releasePayload = await (await releaseResponsePromise).json()
  118 |   const release = record(releasePayload, 'release')
  119 |   const releaseId = typeof release.application_release_id === 'string'
  120 |     ? release.application_release_id
  121 |     : responseID(releasePayload, 'create release', 'release')
  122 | 
  123 |   await expect(page.getByRole('button', { name: new RegExp(`Workspace context\\..*${releaseName}`) })).toBeVisible({ timeout: 15_000 })
  124 |   await expect.poll(() => routeScope(page.url()).get('releaseId')).toBe(releaseId)
  125 | 
  126 |   await page.getByRole('button', { name: 'Repository', exact: true }).click()
  127 |   await expect(page.getByRole('heading', { level: 1, name: 'Repository' })).toBeVisible({ timeout: 15_000 })
  128 | 
  129 |   const repositoryTabs = page.getByRole('tablist', { name: 'Repository asset types' })
  130 |   await repositoryTabs.getByRole('tab', { name: /Projects/ }).click()
  131 |   await expect(page.getByRole('main').getByRole('button', { name: ownerProjectName, exact: true }).first()).toBeVisible()
  132 |   await repositoryTabs.getByRole('tab', { name: /Releases/ }).click()
  133 |   await expect(page.getByRole('main').getByRole('button', { name: releaseName, exact: true }).first()).toBeVisible()
  134 | 
  135 |   const finalScope = routeScope(page.url())
  136 |   expect(finalScope.get('projectId')).toBe(ownerProjectId)
  137 |   expect(finalScope.get('applicationId')).toBe(applicationId)
  138 |   expect(finalScope.get('releaseId')).toBe(releaseId)
  139 |   return { label, domainId, categoryId, projectId: ownerProjectId, applicationId, releaseId }
  140 | }
  141 | 
  142 | export async function json(response: APIResponse | Response): Promise<Record<string, unknown>> {
> 143 |   expect(response.ok(), await response.text()).toBeTruthy()
      |                                                ^ Error: {"error":"Batch publication failed; retry the same operation"}
  144 |   return response.json()
  145 | }
  146 | export function idOf(payload: Record<string, unknown>, key?: string): string {
  147 |   return responseID(payload, 'resource', key)
  148 | }
  149 | /** The script editor's save state, as its status row shows it. */
  150 | export async function expectEditorSaved(page: Page) {
  151 |   await expect(page.getByRole('list', { name: 'Script status' }).getByRole('listitem').filter({ hasText: /^Saved/ })).toBeVisible()
  152 | }
  153 | 
  154 | /** The last debug run's outcome: Debug's session bar owns it, Author's status row repeats it. */
  155 | export async function expectDebugOutcome(page: Page, outcome: 'passed' | 'failed') {
  156 |   const badge = page.locator('.debug-session-bar .replay-live-badge').filter({ hasText: outcome === 'passed' ? /^Passed$/ : /^Failed$/ })
  157 |   const chip = page.getByRole('list', { name: 'Script status' }).getByRole('listitem').filter({ hasText: outcome === 'passed' ? /^Debugged/ : /^Debug failed/ })
  158 |   await expect(badge.or(chip).first()).toBeVisible()
  159 | }
  160 | 
  161 | export function mutation(page: Page, method: string, path: string) {
  162 |   return page.waitForResponse(r => r.request().method() === method && new URL(r.url()).pathname === path)
  163 | }
  164 | export async function login(page: Page, username = 'admin') {
  165 |   // Workflow tests share a controller and source IP. Pace real UI logins below
  166 |   // its ten-per-minute limit rather than retrying failures or weakening auth.
  167 |   await new Promise(resolve => setTimeout(resolve, 6500))
  168 |   await page.goto('/#/dashboard')
  169 |   await page.getByLabel('Username').fill(username)
  170 |   await page.getByLabel('Password').fill(username)
  171 |   await page.getByRole('button', { name: 'Sign in', exact: true }).click()
  172 |   await expect(page.getByRole('heading', { level: 1, name: 'Dashboard' })).toBeVisible()
  173 | }
  174 | /** The collapsed sidebar keeps the account card, with Sign out, behind its avatar; open it. */
  175 | export async function showAccountCard(page: Page) {
  176 |   const account = page.getByRole('button', { name: /Open account details$/ })
  177 |   if (await account.isVisible()) await account.click()
  178 | }
  179 | export async function signOut(page: Page) {
  180 |   await showAccountCard(page)
  181 |   await page.getByRole('button', { name: 'Sign out' }).click()
  182 | }
  183 | export async function seedScript(request: APIRequestContext, workspace: Workspace, name = 'Workflow_HTTP', baseURL = 'http://127.0.0.1:1', path = '/orders') {
  184 |   return idOf(await json(await request.post('/api/v1/scripts', { data: {
  185 |     project_id: workspace.projectId,
  186 |     script: { name, version: '1.0.0', protocol: 'http', config: { base_url: baseURL, pacing: { type: 'fixed_interval', interval_ms: 500 } }, actions: [{ name: 'orders', type: 'request', method: 'GET', target: path }] },
  187 |   } })))
  188 | }
  189 | export async function seedScenario(request: APIRequestContext, workspace: Workspace, scriptId: string, name = 'Workflow scenario') {
  190 |   return idOf(await json(await request.post('/api/v1/scenarios', { data: {
  191 |     project_id: workspace.projectId, application_id: workspace.applicationId, name, duration: '2m', scenario_mode: 'vuser_driven', groups: [{ name: 'orders', script_id: scriptId, vusers: 1, ramp_up: '1s' }],
  192 |   } })))
  193 | }
  194 | export async function importOpenAPI(page: Page, name: string, target: string) {
  195 |   await page.getByRole('button', { name: 'Scripts', exact: true }).click()
  196 |   // Navigate through the actual creation entry rather than seeding the script.
  197 |   await page.getByRole('button', { name: 'Script builder', exact: true }).first().click()
  198 |   await page.getByRole('tab', { name: 'Import', exact: true }).click()
  199 |   await page.getByRole('button', { name: /OpenAPI \/ Swagger/ }).click()
  200 |   const controls = page.getByRole('group', { name: 'Script import controls' })
  201 |   const spec = { openapi: '3.0.3', info: { title: name, version: '1.0' }, servers: [{ url: target }], paths: { '/orders': { get: { operationId: 'listOrders', responses: { '200': { description: 'Orders' } } } } } }
  202 |   await controls.locator('input[type=file]').setInputFiles({ name: 'orders.openapi.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(spec)) })
  203 |   await controls.getByRole('textbox', { name: 'Script Name' }).fill(name)
  204 |   await controls.getByText('Advanced validation only', { exact: true }).click()
  205 |   await controls.getByRole('button', { name: 'Validate Only' }).click()
  206 |   await expect(controls.getByText(/dry-run validation; nothing has been saved/i)).toBeVisible()
  207 |   await controls.locator('.import-source-setup > summary').click()
  208 |   await controls.getByRole('button', { name: 'Inspect & review' }).click()
  209 |   await expect(controls.getByRole('heading', { name: 'Review Generated Script' })).toBeVisible()
  210 |   const saved = mutation(page, 'POST', '/api/v1/scripts/import/openapi/commit')
  211 |   await controls.getByRole('button', { name: 'Save draft' }).click()
  212 |   const scriptId = idOf(await json(await saved), 'stored_script')
  213 |   await controls.getByRole('button', { name: `Open ${name} in Visual Editor`, exact: true }).click()
  214 |   return scriptId
  215 | }
  216 | export async function buildScenarioUI(page: Page, scriptName: string, name: string) {
  217 |   await page.getByRole('button', { name: 'New run', exact: true }).first().click()
  218 |   await page.getByRole('button', { name: 'Open scenario builder' }).click()
  219 |   const steps = page.locator('[aria-label="Scenario builder steps"]')
  220 |   await page.getByPlaceholder('Scenario name').fill(name)
  221 |   await page.getByRole('button', { name: 'Add script to Group 1' }).click()
  222 |   await page.getByRole('row').filter({ hasText: scriptName }).getByRole('button', { name: 'Use for Group 1' }).click()
  223 |   await steps.getByRole('button', { name: /^Model/ }).click()
  224 |   await page.getByRole('button', { name: /^Fixed VUsers/ }).click()
  225 |   await page.getByRole('button', { name: 'Use Closed VUser', exact: true }).click()
  226 |   await steps.getByRole('button', { name: /^Run settings/ }).click()
  227 |   const scenarioTabs = page.getByRole('tablist', { name: 'Run settings sections' })
  228 |   await scenarioTabs.getByRole('tab', { name: 'Run phases' }).click()
  229 |   await page.getByLabel('Ramp-up', { exact: true }).fill('1')
  230 |   await page.getByLabel('Ramp-up Unit').selectOption('s')
  231 |   await page.getByLabel('Sustained load', { exact: true }).fill('1')
  232 |   await page.getByLabel('Sustained load Unit').selectOption('m')
  233 |   await scenarioTabs.getByRole('tab', { name: 'Target load' }).click()
  234 |   await page.getByLabel('Peak VUsers', { exact: true }).fill('1')
  235 |   await steps.getByRole('button', { name: /^Data/ }).click()
  236 |   await page.getByRole('button', { name: 'Next', exact: true }).click()
  237 |   await expect(page.getByRole('heading', { name: 'Review and validate' })).toBeVisible()
  238 |   const saved = mutation(page, 'POST', '/api/v1/scenarios')
  239 |   await page.getByRole('button', { name: 'Save and configure run' }).click()
  240 |   const payload = await json(await saved)
  241 |   return idOf(payload)
  242 | }
  243 | export async function runStatus(request: APIRequestContext, id: string) {
```