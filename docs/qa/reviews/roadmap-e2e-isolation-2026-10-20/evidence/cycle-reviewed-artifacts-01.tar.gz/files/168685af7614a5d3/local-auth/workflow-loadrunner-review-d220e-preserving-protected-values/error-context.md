# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-loadrunner-review.spec.ts >> LoadRunner credentials edit and apply in place while preserving protected values
- Location: e2e/workflow-loadrunner-review.spec.ts:570:1

# Error details

```
Error: expect(received).toBeTruthy()

Received: false
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to main content" [ref=f2e4] [cursor=pointer]:
    - /url: "#app-main"
  - complementary [ref=f2e6] [cursor=pointer]:
    - button "APEX Load dashboard" [ref=f2e7]:
      - img "APEX Load" [ref=f2e8]
    - button "Workspace context. e2e-1792519620344-933026 domain / e2e-1792519620344-933026 project / e2e-1792519620344-933026 application / e2e-1792519620344-933026 1.0" [ref=f2e15]:
      - generic [aria-hidden] [ref=f2e16]: ◈
    - navigation "Primary navigation" [ref=f2e17]:
      - button "New run" [ref=f2e19]
      - generic [ref=f2e24]:
        - button "Dashboard" [ref=f2e26]
        - button "Command Center" [ref=f2e34]
        - button "Results" [ref=f2e41]
        - button "Monitoring" [ref=f2e45]
        - button "Activity" [ref=f2e50]
      - generic [ref=f2e54]:
        - button "Scripts" [ref=f2e56]
        - button "Scenarios" [ref=f2e62]
        - button "Shared assets" [ref=f2e67]
      - generic [ref=f2e73]:
        - button "Repository" [ref=f2e75]
        - button "Access" [ref=f2e81]
        - button "Settings" [ref=f2e88]
      - button "Help & documentation" [ref=f2e95]
    - generic [ref=f2e100]:
      - generic [ref=f2e101]:
        - button "Local System Administrator. System Admin. Open account details" [ref=f2e103]:
          - generic [aria-hidden] [ref=f2e104]: LS
        - generic [ref=f2e105]:
          - 'status "Live connection: Live" [ref=f2e106]':
            - generic [ref=f2e108]:
              - generic [ref=f2e109]: "Live connection:"
              - text: Live
          - 'button "Build info: local · dev" [ref=f2e111]'
      - button "Expand sidebar" [ref=f2e114]
  - main [ref=f2e117]:
    - status [ref=f2e118]: Import LoadRunner Script Archive
    - generic "Dashboard controls" [ref=f2e119]:
      - heading "Import LoadRunner Script Archive" [level=1] [ref=f2e121]
      - generic [ref=f2e122]:
        - link "Help for this page" [ref=f2e123] [cursor=pointer]:
          - /url: "#/docs?guide=user-guide&article=imports"
        - generic "Deployment identity" [ref=f2e124]:
          - generic "You are using APEX Load in a web browser; tests run on the Server controller." [ref=f2e125]:
            - text: Web app · Server
            - generic [ref=f2e127]: . You are using APEX Load in a web browser; tests run on the Server controller.
        - combobox "Dashboard color theme" [ref=f2e129] [cursor=pointer]:
          - option "System (Auto)"
          - option "Dark Theme"
          - option "Light Theme" [selected]
          - option "Solarized Dark"
          - option "Solarized Light"
          - option "Monokai Dimmed"
    - group "Script import controls" [ref=f2e132]:
      - generic [ref=f2e133]:
        - generic [ref=f2e134]:
          - paragraph [ref=f2e136]: Choose an uncompressed VuGen script folder or a LoadRunner ZIP or USZ archive, including source, runtime settings, parameter files, and dependencies. We detect the protocol and show what can be saved, what needs repair, and whether a runner is required. Import checks do not execute your script.
          - button "Back" [ref=f2e137] [cursor=pointer]
        - list "Import workflow" [ref=f2e138]:
          - listitem [ref=f2e139]:
            - generic [aria-hidden] [ref=f2e140]: "1"
            - generic [ref=f2e141]: Upload archives
          - listitem [ref=f2e142]:
            - generic [aria-hidden] [ref=f2e143]: "2"
            - generic [ref=f2e144]: Review and resolve
          - listitem [ref=f2e145]:
            - generic [aria-hidden] [ref=f2e146]: "3"
            - generic [ref=f2e147]: Save script or review draft
          - listitem [ref=f2e148]:
            - generic [aria-hidden] [ref=f2e149]: "4"
            - generic [ref=f2e150]: Debug one iteration
        - group "Add enterprise script archives or VuGen folders. 1 currently queued" [ref=f2e151]:
          - generic [ref=f2e153]:
            - generic [ref=f2e154]:
              - generic [ref=f2e158]:
                - generic [ref=f2e159]: 1 archive queued
                - button "Add archives" [ref=f2e160] [cursor=pointer]
                - button "Add folder" [ref=f2e161] [cursor=pointer]
              - button "Clear All" [ref=f2e162] [cursor=pointer]
            - generic "Queued enterprise script archives" [ref=f2e163]:
              - generic [ref=f2e164]:
                - button "credential-groups.zip 0.5 KB · Failed" [pressed] [ref=f2e165] [cursor=pointer]:
                  - generic [ref=f2e166]:
                    - strong [ref=f2e167]: credential-groups.zip
                    - generic [ref=f2e168]:
                      - text: 0.5 KB ·
                      - generic [ref=f2e169]: Failed
                    - alert [ref=f2e170]: credential-preserving import draft could not be secured; retry the import (ref db3e6abe9357fb5d)
                - button "Remove credential-groups.zip" [ref=f2e171] [cursor=pointer]: Remove
        - status [ref=f2e172]: 0 scripts saved · 0 review sessions saved · 0 approval sessions queued · 0 drafts awaiting save · 0 archives validated, awaiting save · 1 archive failed
        - group [ref=f2e173]:
          - generic "Archive setup" [ref=f2e174] [cursor=pointer]
          - generic [ref=f2e175]:
            - generic [ref=f2e176]:
              - generic [ref=f2e177]:
                - heading "Conversion Options" [level=3] [ref=f2e178]
                - button "Runtime Settings Coverage" [ref=f2e179] [cursor=pointer]
              - generic [ref=f2e180]:
                - generic [ref=f2e181]:
                  - generic [ref=f2e182]: Script Name (optional)
                  - textbox "Script Name (optional)" [ref=f2e183]:
                    - /placeholder: Auto-detected from .usr file
                - generic [ref=f2e184]:
                  - generic [ref=f2e185]: Base URL Override (optional)
                  - textbox "Base URL Override (optional)" [ref=f2e186]:
                    - /placeholder: Auto-detected from first URL
                - generic [ref=f2e187]:
                  - checkbox "Add default status_code assertions" [checked] [ref=f2e188] [cursor=pointer]
                  - generic [ref=f2e189]: Add default status_code assertions
                - generic [ref=f2e190]:
                  - checkbox "Preserve transaction names in generated actions" [checked] [ref=f2e191] [cursor=pointer]
                  - generic [ref=f2e192]: Preserve transaction names in generated actions
                - group [ref=f2e193]:
                  - generic "Advanced migration policy" [ref=f2e194] [cursor=pointer]
                - group [ref=f2e195]:
                  - generic "Salesforce-specific options" [ref=f2e196] [cursor=pointer]
              - paragraph [ref=f2e197]: "Selected migration block policy: Blocked"
            - generic [ref=f2e198]:
              - generic [ref=f2e199]:
                - heading "Validation / Conversion" [level=3] [ref=f2e200]
                - paragraph [ref=f2e201]: 1 archive queued
              - generic [ref=f2e202]:
                - generic [ref=f2e203]:
                  - heading "Required Files" [level=4] [ref=f2e204]
                  - paragraph [ref=f2e205]: Validate the archive to check for missing dependencies.
                - button "Attach Required Files" [ref=f2e207] [cursor=pointer]
              - generic [ref=f2e208]:
                - button "Validate Script" [ref=f2e209] [cursor=pointer]
                - button "Save draft" [disabled] [ref=f2e210]
              - paragraph [ref=f2e211]: 1 archive must pass validation before conversion.
        - paragraph [ref=f2e213]: Protocol-aware detection uses .usr metadata plus source signatures. Conflicting evidence is gated for review instead of being saved as an executable script.
        - generic "enterprise protocol import coverage" [ref=f2e214]:
          - button "Import Coverage" [ref=f2e215] [cursor=pointer]
        - alert [ref=f2e216]: 1 enterprise script archive failed during import review. Failed queue rows show the error details.
        - alert [ref=f2e217]: credential-preserving import draft could not be secured; retry the import (ref db3e6abe9357fb5d)
```

# Test source

```ts
  482 |   await expect(page.locator('.import-runtime-table thead th').first()).toHaveCSS('position', 'static')
  483 |   await page.getByRole('navigation', { name: 'Runtime categories' }).getByRole('button', { name: /^HTTP/ }).click()
  484 |   await expect(page.locator('.import-runtime-table thead th').first()).toHaveCSS('position', 'sticky')
  485 |   await expect(page.getByRole('button', { name: 'Edit HTTP', exact: true })).toBeVisible()
  486 |   await page.getByRole('button', { name: 'Edit HTTP', exact: true }).click()
  487 |   const timeout = page.getByRole('spinbutton', { name: 'HTTP: Request timeout (ms)', exact: true })
  488 |   await timeout.fill('-1')
  489 |   const invalidApply = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  490 |   await page.getByRole('button', { name: 'Apply HTTP', exact: true }).click()
  491 |   expect((await invalidApply).status()).toBe(422)
  492 |   await expect(timeout).toHaveValue('-1')
  493 |   await expect(timeout).toHaveAttribute('aria-invalid', 'true')
  494 |   await expect(page.getByRole('alert')).toContainText('Enter a valid number value')
  495 |   await timeout.fill('8500')
  496 |   await page.getByRole('navigation', { name: 'Runtime categories' }).getByRole('button', { name: /^Think time/ }).click()
  497 |   await expect(timeout).toHaveCount(0)
  498 |   await page.getByRole('button', { name: 'Review HTTP edits', exact: true }).click()
  499 |   await expect(timeout).toHaveValue('8500')
  500 |   await page.getByRole('tab', { name: /^Data & parameters(,|$)/ }).click()
  501 |   await expect(page.getByText(/Finish editing HTTP/)).toBeVisible()
  502 |   await page.getByRole('tab', { name: /^Runtime settings(,|$)/ }).click()
  503 |   await expect(timeout).toHaveValue('8500')
  504 |   const runtimeApply = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  505 |   await page.getByRole('button', { name: 'Apply HTTP', exact: true }).click()
  506 |   const runtimeResponse = await runtimeApply
  507 |   expect(runtimeResponse.ok(), await runtimeResponse.text()).toBeTruthy()
  508 |   const runtimeResult = await json(runtimeResponse)
  509 |   expect((runtimeResult.script as ScriptDefinition).config.http?.request_timeout_ms).toBe(8500)
  510 |   await expect(page.getByRole('region', { name: 'Mapped for replay', exact: true })).toContainText('ReceiveTimeout: 30')
  511 |   await page.screenshot({ path: testInfo.outputPath('runtime-settings-desktop.png'), fullPage: true })
  512 |   await page.getByRole('tab', { name: /^Data & parameters(,|$)/ }).click()
  513 |   await page.getByRole('tab', { name: /^Data sources \(/ }).click()
  514 |   await expect(page.getByRole('heading', { name: 'Data sources', exact: true })).toHaveCount(1)
  515 |   await page.getByRole('tab', { name: /^Parameters \(/ }).click()
  516 |   await expect(page.getByRole('tabpanel', { name: /^Parameters/ })).toContainText('Sample: west, east')
  517 |   await page.getByRole('button', { name: 'Edit region', exact: true }).click()
  518 |   await page.getByRole('combobox', { name: 'region: selection', exact: true }).selectOption('unique')
  519 |   const startRow = page.getByRole('spinbutton', { name: 'region: start row', exact: true })
  520 |   const blockSize = page.getByRole('spinbutton', { name: 'region: block size', exact: true })
  521 |   await startRow.fill('-1')
  522 |   await blockSize.fill('-1')
  523 |   const invalidParameters = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  524 |   await page.getByRole('button', { name: 'Apply file', exact: true }).click()
  525 |   expect((await invalidParameters).status()).toBe(422)
  526 |   await startRow.fill('1')
  527 |   await expect(blockSize).toHaveAttribute('aria-invalid', 'true')
  528 |   await blockSize.fill('0')
  529 |   await page.getByRole('combobox', { name: 'region: auto allocate', exact: true }).selectOption('true')
  530 |   await page.getByRole('combobox', { name: 'region: selection', exact: true }).selectOption('random')
  531 |   await expect(page.getByRole('combobox', { name: 'region: auto allocate', exact: true })).toBeVisible()
  532 |   await page.getByRole('combobox', { name: 'region: auto allocate', exact: true }).selectOption('false')
  533 |   await page.getByRole('searchbox', { name: 'Find a parameter', exact: true }).fill('missing-parameter')
  534 |   await expect(page.getByText('No parameters match these filters.', { exact: true })).toBeVisible()
  535 |   await page.getByRole('button', { name: 'Review file edits', exact: true }).click()
  536 |   await expect(page.getByRole('combobox', { name: 'region: selection', exact: true })).toHaveValue('random')
  537 |   await page.getByRole('tab', { name: /^Data sources \(/ }).click()
  538 |   await expect(page.getByRole('combobox', { name: 'region: selection', exact: true })).toHaveCount(0)
  539 |   await page.getByRole('tablist', { name: 'Data views' }).getByRole('tab', { name: 'Allocation preview', exact: true }).click()
  540 |   await page.getByText(/^Allocation rules \(/).click()
  541 |   await page.getByRole('button', { name: 'Edit region rules', exact: true }).click()
  542 |   await expect(page.getByRole('tab', { name: /^Parameters/ })).toHaveAttribute('aria-selected', 'true')
  543 |   await expect(page.getByRole('combobox', { name: 'region: selection', exact: true })).toHaveValue('random')
  544 |   const parameterApply = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  545 |   await page.getByRole('button', { name: 'Apply file', exact: true }).click()
  546 |   const parameterResponse = await parameterApply
  547 |   expect(parameterResponse.ok(), await parameterResponse.text()).toBeTruthy()
  548 |   const parameterResult = await json(parameterResponse)
  549 |   expect((parameterResult.script as ScriptDefinition).parameters?.find(p => p.name === 'region')?.selection).toBe('random')
  550 |   await page.setViewportSize({ width: 760, height: 1000 })
  551 |   await expect.poll(() => page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true)
  552 |   await page.screenshot({ path: testInfo.outputPath('data-settings-narrow.png'), fullPage: true })
  553 |   await page.getByRole('tab', { name: 'Source Mapping', exact: true }).click()
  554 |   await expect(page.getByRole('heading', { name: 'Source files & import metadata', exact: true })).toBeHidden()
  555 |   await page.locator('.import-source-inventory > summary').click()
  556 |   await expect(page.getByRole('heading', { name: 'Source files & import metadata', exact: true })).toBeVisible()
  557 |   await expect(page.getByRole('tabpanel').locator('.lr-preserved-card')).toHaveCount(0)
  558 |   await page.getByRole('tab', { name: /^Review(,|$)/ }).click()
  559 |   const saved = mutation(page, 'POST', '/api/v1/scripts/import/enterprise-script-archive/save')
  560 |   await page.locator('.script-import-review-actions').getByRole('button', { name: /Save/ }).click()
  561 |   const savedResponse = await saved
  562 |   expect(savedResponse.ok(), await savedResponse.text()).toBeTruthy()
  563 |   const savedResult = await json(savedResponse)
  564 |   const savedScript = (savedResult.scripts as { script: ScriptDefinition }[])[0].script
  565 |   expect(savedScript.config.http?.request_timeout_ms).toBe(8500)
  566 |   expect(savedScript.parameters?.find(p => p.name === 'region')?.selection).toBe('random')
  567 | })
  568 | 
  569 | 
  570 | test('LoadRunner credentials edit and apply in place while preserving protected values', async ({ page }, testInfo) => {
  571 |   test.setTimeout(90_000)
  572 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  573 |   const workspace = await createWorkspace(page.context().request)
  574 |   await page.goto(`/#/scripts?mode=create&${scopeQuery(workspace)}`)
  575 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await page.reload()
  576 |   await page.getByRole('tab', { name: 'Import', exact: true }).click()
  577 |   await page.getByRole('button', { name: /LoadRunner Script Archive/ }).click()
  578 |   await page.locator('input[type=file][accept=".zip,.usz"]').setInputFiles(path.join(process.cwd(), 'e2e/fixtures/credential-groups.zip'))
  579 |   const validated = mutation(page, 'POST', '/api/v1/scripts/import/enterprise-script-archive/validate')
  580 |   await page.getByRole('button', { name: 'Validate Script', exact: true }).click()
  581 |   const validatedResponse = await validated
> 582 |   expect(validatedResponse.ok()).toBeTruthy()
      |                                  ^ Error: expect(received).toBeTruthy()
  583 |   const validatedResult = await json(validatedResponse)
  584 |   const validatedDraft = canonicalImportDraft(validatedResult)
  585 |   await page.getByRole('tab', { name: /^Credentials(,|$)/ }).click()
  586 |   const review = page.locator('.secret-binding-review')
  587 |   await expect(review).not.toContainText('test-only-token')
  588 |   await expect(review.locator('.credential-inline-current')).toContainText('Preserved · hidden')
  589 |   await expect(review.locator('input[type=password]')).not.toBeVisible()
  590 |   await review.getByRole('button', { name: 'Edit credentials', exact: true }).click()
  591 |   const destination = review.getByRole('combobox', { name: /^Destination for / })
  592 |   await destination.selectOption('project-secret')
  593 |   const reference = review.getByRole('textbox', { name: 'Secret reference name', exact: true })
  594 |   await reference.fill('CANCELLED_IMPORT_TOKEN')
  595 |   await review.getByRole('button', { name: 'Cancel credentials', exact: true }).click()
  596 |   await expect(review.locator('.credential-inline-current')).toContainText('Preserved · hidden')
  597 |   await review.getByRole('button', { name: 'Edit credentials', exact: true }).click()
  598 |   await destination.selectOption('project-secret')
  599 |   await reference.fill('INLINE_IMPORT_TOKEN')
  600 |   await page.getByRole('tab', { name: /^Runtime settings(,|$)/ }).click()
  601 |   await page.getByRole('checkbox', { name: /Show \d+ unconfigured APEX settings/ }).check()
  602 |   await expect(page.getByRole('button', { name: 'Edit HTTP', exact: true })).toBeDisabled()
  603 |   await page.getByRole('tab', { name: /^Credentials(,|$)/ }).click()
  604 |   await expect(reference).toHaveValue('INLINE_IMPORT_TOKEN')
  605 |   const saveDraft = page.locator('.script-import-review-actions').getByRole('button', { name: /^Save draft(?: with.*)?$/i })
  606 |   await expect(saveDraft).toBeDisabled()
  607 |   await expect(review.locator('input[type=password]')).toHaveValue('')
  608 |   await page.screenshot({ path: testInfo.outputPath('credentials-inline-edit.png'), fullPage: true })
  609 |   const applied = mutation(page, 'POST', '/api/v1/scripts/secret-bindings/apply')
  610 |   await review.getByRole('button', { name: 'Apply credentials', exact: true }).click()
  611 |   const response = await applied
  612 |   expect(response.ok(), await response.text()).toBeTruthy()
  613 |   const updated = await json(response)
  614 |   expect(JSON.stringify(updated.script)).toContain('{{secret.INLINE_IMPORT_TOKEN}}')
  615 |   expect(JSON.stringify((updated.script as ScriptDefinition).actions)).not.toContain('test-only-token')
  616 |   expect((updated.script as ScriptDefinition).metadata?.import?.preserved?.source_review).toEqual(validatedDraft.metadata?.import?.preserved?.source_review)
  617 |   await expect(page.getByRole('tab', { name: /^Credentials(,|$)/ })).toHaveAttribute('aria-selected', 'true')
  618 |   await expect(page.getByRole('button', { name: 'Cancel credentials', exact: true })).toHaveCount(0)
  619 |   const saved = mutation(page, 'POST', '/api/v1/scripts/import/enterprise-script-archive/save')
  620 |   await page.locator('.script-import-review-actions').getByRole('button', { name: 'Save to script library', exact: true }).click()
  621 |   const savedResponse = await saved
  622 |   expect(savedResponse.ok(), await savedResponse.text()).toBeTruthy()
  623 |   const savedResult = await json(savedResponse)
  624 |   expect(JSON.stringify(savedResult.scripts)).toContain('{{secret.INLINE_IMPORT_TOKEN}}')
  625 |   const savedScript = (savedResult.scripts as { script: ScriptDefinition }[])[0].script
  626 |   expect(JSON.stringify(savedScript.actions)).not.toContain('test-only-token')
  627 | })
  628 | 
  629 | test('LoadRunner percentage think time shows source bounds and saves edited percentages', async ({ page }, testInfo) => {
  630 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  631 |   const workspace = await createWorkspace(page.context().request)
  632 |   await page.goto(`/#/scripts?mode=create&${scopeQuery(workspace)}`)
  633 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await page.reload()
  634 |   await page.getByRole('tab', { name: 'Import', exact: true }).click()
  635 |   await page.getByRole('button', { name: /LoadRunner Script Archive/ }).click()
  636 |   await page.locator('input[type=file][accept=".zip,.usz"]').setInputFiles(path.join(process.cwd(), 'e2e/fixtures/runtime-percentages.zip'))
  637 |   const validation = mutation(page, 'POST', '/api/v1/scripts/import/enterprise-script-archive/validate')
  638 |   await page.getByRole('button', { name: 'Validate Script', exact: true }).click()
  639 |   expect((await validation).ok()).toBeTruthy()
  640 |   await page.getByRole('tab', { name: /^Runtime settings(,|$)/ }).click()
  641 |   await showAllRuntimeStatuses(page)
  642 |   await page.getByRole('navigation', { name: 'Runtime categories' }).getByRole('button', { name: /^Think time/ }).click()
  643 |   const mapped = page.getByRole('region', { name: 'Mapped for replay', exact: true })
  644 |   await expect(mapped).toContainText('ThinkTimeRandomLow: 50')
  645 |   await expect(mapped).toContainText('ThinkTimeRandomHigh: 150')
  646 |   await expect(page.getByRole('tabpanel')).not.toContainText('Source value unavailable')
  647 |   await page.getByRole('navigation', { name: 'Runtime categories' }).getByRole('button', { name: /^Think time/ }).click()
  648 |   await page.getByRole('button', { name: 'Edit Think time', exact: true }).click()
  649 |   const low = page.getByRole('spinbutton', { name: 'Think time: Minimum recorded delay (%)', exact: true })
  650 |   const high = page.getByRole('spinbutton', { name: 'Think time: Maximum recorded delay (%)', exact: true })
  651 |   await low.fill('175')
  652 |   const invalid = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  653 |   await page.getByRole('button', { name: 'Apply Think time', exact: true }).click()
  654 |   expect((await invalid).status()).toBe(422)
  655 |   await expect(low).toHaveValue('175')
  656 |   await low.fill('25')
  657 |   await high.fill('125')
  658 |   const applying = mutation(page, 'POST', '/api/v1/scripts/import/settings')
  659 |   await page.getByRole('button', { name: 'Apply Think time', exact: true }).click()
  660 |   const response = await applying
  661 |   expect(response.ok(), await response.text()).toBeTruthy()
  662 |   const result = await json(response)
  663 |   expect((result.script as ScriptDefinition).config.think_time).toMatchObject({ type: 'random_percentage', min_percent: 25, max_percent: 125 })
  664 |   await expect(mapped).toContainText('ThinkTimeRandomLow: 50')
  665 |   await mapped.getByRole('row', { name: /^Minimum recorded delay/ }).scrollIntoViewIfNeeded()
  666 |   await page.screenshot({ path: testInfo.outputPath('percentage-runtime-settings.png'), fullPage: true })
  667 |   await page.getByRole('tab', { name: /^Review(,|$)/ }).click()
  668 |   const saving = mutation(page, 'POST', '/api/v1/scripts/import/enterprise-script-archive/save')
  669 |   await page.locator('.script-import-review-actions').getByRole('button', { name: /Save/ }).click()
  670 |   const saved = await saving
  671 |   expect(saved.ok(), await saved.text()).toBeTruthy()
  672 |   expect(((await json(saved)).scripts as { script: ScriptDefinition }[])[0].script.config.think_time).toMatchObject({ type: 'random_percentage', min_percent: 25, max_percent: 125 })
  673 | })
  674 | 
  675 | test('LoadRunner runtime context explains inactive settings and repairs an oversized idle timeout', async ({ page }, testInfo) => {
  676 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  677 |   const workspace = await createWorkspace(page.context().request)
  678 |   await page.goto(`/#/scripts?mode=create&${scopeQuery(workspace)}`)
  679 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await page.reload()
  680 |   await page.getByRole('tab', { name: 'Import', exact: true }).click()
  681 |   await page.getByRole('button', { name: /LoadRunner Script Archive/ }).click()
  682 |   await page.locator('input[type=file][accept=".zip,.usz"]').setInputFiles(path.join(process.cwd(), 'e2e/fixtures/runtime-context.zip'))
```