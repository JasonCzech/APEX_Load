# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-loadrunner-review.spec.ts >> LoadRunner review renders real sap-review.zip response
- Location: e2e/workflow-loadrunner-review.spec.ts:55:3

# Error details

```
Error: {"code":"import_draft_attestation_unavailable","error":"credential-preserving import draft could not be secured; retry the import","ref":"2b499579f8e4a5f3","retryable":true}


expect(received).toBeTruthy()

Received: false
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to main content" [ref=f2e4] [cursor=pointer]:
    - /url: "#app-main"
  - complementary [ref=f2e6] [cursor=pointer]:
    - button "APEX Load dashboard" [ref=f2e7]:
      - img "APEX Load" [ref=f2e8]
    - button "Workspace context. e2e-1792519577855-816619 domain / e2e-1792519577855-816619 project / e2e-1792519577855-816619 application / e2e-1792519577855-816619 1.0" [ref=f2e15]:
      - generic [aria-hidden] [ref=f2e16]: ◈
    - navigation "Primary navigation" [ref=f2e17]:
      - button "New run" [ref=f2e19]
      - generic [ref=f2e24]:
        - button "Dashboard" [ref=f2e26]
        - button "Command Center" [ref=f2e34]
        - button "Results" [ref=f2e41]
        - button "Monitoring" [ref=f2e45]
        - button "Activity" [ref=f2e50]
      - generic [ref=f2e54]:
        - button "Scripts" [ref=f2e56]
        - button "Scenarios" [ref=f2e62]
        - button "Shared assets" [ref=f2e67]
      - generic [ref=f2e73]:
        - button "Repository" [ref=f2e75]
        - button "Access" [ref=f2e81]
        - button "Settings" [ref=f2e88]
      - button "Help & documentation" [ref=f2e95]
    - generic [ref=f2e100]:
      - generic [ref=f2e101]:
        - button "Local System Administrator. System Admin. Open account details" [ref=f2e103]:
          - generic [aria-hidden] [ref=f2e104]: LS
        - generic [ref=f2e105]:
          - 'status "Live connection: Live" [ref=f2e106]':
            - generic [ref=f2e108]:
              - generic [ref=f2e109]: "Live connection:"
              - text: Live
          - 'button "Build info: local · dev" [ref=f2e111]'
      - button "Expand sidebar" [ref=f2e114]
  - main [ref=f2e117]:
    - status [ref=f2e118]: Import LoadRunner Script Archive
    - generic "Dashboard controls" [ref=f2e119]:
      - heading "Import LoadRunner Script Archive" [level=1] [ref=f2e121]
      - generic [ref=f2e122]:
        - link "Help for this page" [ref=f2e123] [cursor=pointer]:
          - /url: "#/docs?guide=user-guide&article=imports"
        - generic "Deployment identity" [ref=f2e124]:
          - generic "You are using APEX Load in a web browser; tests run on the Server controller." [ref=f2e125]:
            - text: Web app · Server
            - generic [ref=f2e127]: . You are using APEX Load in a web browser; tests run on the Server controller.
        - combobox "Dashboard color theme" [ref=f2e129] [cursor=pointer]:
          - option "System (Auto)"
          - option "Dark Theme"
          - option "Light Theme" [selected]
          - option "Solarized Dark"
          - option "Solarized Light"
          - option "Monokai Dimmed"
    - group "Script import controls" [ref=f2e132]:
      - generic [ref=f2e133]:
        - generic [ref=f2e134]:
          - paragraph [ref=f2e136]: Choose an uncompressed VuGen script folder or a LoadRunner ZIP or USZ archive, including source, runtime settings, parameter files, and dependencies. We detect the protocol and show what can be saved, what needs repair, and whether a runner is required. Import checks do not execute your script.
          - button "Back" [ref=f2e137] [cursor=pointer]
        - list "Import workflow" [ref=f2e138]:
          - listitem [ref=f2e139]:
            - generic [aria-hidden] [ref=f2e140]: "1"
            - generic [ref=f2e141]: Upload archives
          - listitem [ref=f2e142]:
            - generic [aria-hidden] [ref=f2e143]: "2"
            - generic [ref=f2e144]: Review and resolve
          - listitem [ref=f2e145]:
            - generic [aria-hidden] [ref=f2e146]: "3"
            - generic [ref=f2e147]: Save script or review draft
          - listitem [ref=f2e148]:
            - generic [aria-hidden] [ref=f2e149]: "4"
            - generic [ref=f2e150]: Debug one iteration
        - group "Add enterprise script archives or VuGen folders. 1 currently queued" [ref=f2e151]:
          - generic [ref=f2e153]:
            - generic [ref=f2e154]:
              - generic [ref=f2e158]:
                - generic [ref=f2e159]: 1 archive queued
                - button "Add archives" [ref=f2e160] [cursor=pointer]
                - button "Add folder" [ref=f2e161] [cursor=pointer]
              - button "Clear All" [ref=f2e162] [cursor=pointer]
            - generic "Queued enterprise script archives" [ref=f2e163]:
              - generic [ref=f2e164]:
                - button "sap-review.zip 0.3 KB · Failed" [pressed] [ref=f2e165] [cursor=pointer]:
                  - generic [ref=f2e166]:
                    - strong [ref=f2e167]: sap-review.zip
                    - generic [ref=f2e168]:
                      - text: 0.3 KB ·
                      - generic [ref=f2e169]: Failed
                    - alert [ref=f2e170]: credential-preserving import draft could not be secured; retry the import (ref 2b499579f8e4a5f3)
                - button "Remove sap-review.zip" [ref=f2e171] [cursor=pointer]: Remove
        - status [ref=f2e172]: 0 scripts saved · 0 review sessions saved · 0 approval sessions queued · 0 drafts awaiting save · 0 archives validated, awaiting save · 1 archive failed
        - group [ref=f2e173]:
          - generic "Archive setup" [ref=f2e174] [cursor=pointer]
          - generic [ref=f2e175]:
            - generic [ref=f2e176]:
              - generic [ref=f2e177]:
                - heading "Conversion Options" [level=3] [ref=f2e178]
                - button "Runtime Settings Coverage" [ref=f2e179] [cursor=pointer]
              - generic [ref=f2e180]:
                - generic [ref=f2e181]:
                  - generic [ref=f2e182]: Script Name (optional)
                  - textbox "Script Name (optional)" [ref=f2e183]:
                    - /placeholder: Auto-detected from .usr file
                - generic [ref=f2e184]:
                  - generic [ref=f2e185]: Base URL Override (optional)
                  - textbox "Base URL Override (optional)" [ref=f2e186]:
                    - /placeholder: Auto-detected from first URL
                - generic [ref=f2e187]:
                  - checkbox "Add default status_code assertions" [checked] [ref=f2e188] [cursor=pointer]
                  - generic [ref=f2e189]: Add default status_code assertions
                - generic [ref=f2e190]:
                  - checkbox "Preserve transaction names in generated actions" [checked] [ref=f2e191] [cursor=pointer]
                  - generic [ref=f2e192]: Preserve transaction names in generated actions
                - group [ref=f2e193]:
                  - generic "Advanced migration policy" [ref=f2e194] [cursor=pointer]
                - group [ref=f2e195]:
                  - generic "Salesforce-specific options" [ref=f2e196] [cursor=pointer]
              - paragraph [ref=f2e197]: "Selected migration block policy: Blocked"
            - generic [ref=f2e198]:
              - generic [ref=f2e199]:
                - heading "Validation / Conversion" [level=3] [ref=f2e200]
                - paragraph [ref=f2e201]: 1 archive queued
              - generic [ref=f2e202]:
                - generic [ref=f2e203]:
                  - heading "Required Files" [level=4] [ref=f2e204]
                  - paragraph [ref=f2e205]: Validate the archive to check for missing dependencies.
                - button "Attach Required Files" [ref=f2e207] [cursor=pointer]
              - generic [ref=f2e208]:
                - button "Validate Script" [ref=f2e209] [cursor=pointer]
                - button "Save draft" [disabled] [ref=f2e210]
              - paragraph [ref=f2e211]: 1 archive must pass validation before conversion.
        - paragraph [ref=f2e213]: Protocol-aware detection uses .usr metadata plus source signatures. Conflicting evidence is gated for review instead of being saved as an executable script.
        - generic "enterprise protocol import coverage" [ref=f2e214]:
          - button "Import Coverage" [ref=f2e215] [cursor=pointer]
        - alert [ref=f2e216]: 1 enterprise script archive failed during import review. Failed queue rows show the error details.
        - alert [ref=f2e217]: credential-preserving import draft could not be secured; retry the import (ref 2b499579f8e4a5f3)
```

# Test source

```ts
  43  |     response.request().method() === 'POST'
  44  |     && new URL(response.url()).pathname === '/api/v1/domains'
  45  |   ))
  46  |   await page.getByRole('button', { name: 'Add domain' }).click()
  47  |   const domainPayload = await (await domainResponsePromise).json()
  48  |   const domainId = responseID(domainPayload, 'create domain', 'domain')
  49  |   responseID(domainPayload, 'provision application repository', 'application_repository')
  50  |   const categoryId = responseID(domainPayload, 'default category', 'default_category')
  51  | 
  52  |   await expect(page.getByText(`Domain "${domainName}" created.`)).toBeVisible({ timeout: 15_000 })
  53  |   await expect(page.locator('button.settings-app-card').filter({ hasText: domainName })).toBeVisible()
  54  | 
  55  |   const settingsSections = page.getByRole('navigation', { name: 'Settings sections' })
  56  |   await settingsSections.getByRole('button', { name: 'Projects', exact: true }).click()
  57  |   const projectNameInput = page.getByPlaceholder('Create project, e.g. Customer Portal')
  58  | 
  59  |   const createProject = async (name: string) => {
  60  |     await projectNameInput.fill(name)
  61  |     const responsePromise = page.waitForResponse(response => (
  62  |       response.request().method() === 'POST'
  63  |       && new URL(response.url()).pathname === '/api/v1/projects'
  64  |     ))
  65  |     await page.getByRole('button', { name: 'Add Project' }).click()
  66  |     const payload = await (await responsePromise).json()
  67  |     const project = record(payload, 'project')
  68  |     expect(project.domain_id, `${name} must be created in the UI-selected domain`).toBe(domainId)
  69  |     await expect(page.locator('button.settings-app-card').filter({ hasText: name })).toBeVisible({ timeout: 15_000 })
  70  |     return responseID(payload, `create project ${name}`, 'project')
  71  |   }
  72  | 
  73  |   const ownerProjectId = await createProject(ownerProjectName)
  74  |   const decoyProjectId = await createProject(decoyProjectName)
  75  |   expect(routeScope(page.url()).get('projectId')).toBe(decoyProjectId)
  76  | 
  77  |   // Keep the decoy as the active workspace project, then explicitly target the
  78  |   // owner in the application picker. This is the wrong-project regression:
  79  |   // the picker must move real workspace scope, not only its local form cursor.
  80  |   await settingsSections.getByRole('button', { name: 'Applications & releases' }).click()
  81  |   await page.getByPlaceholder('Create application, e.g. ACC').fill(applicationName)
  82  |   const applicationProject = page.getByRole('combobox', { name: 'Project for the new application' })
  83  |   await applicationProject.selectOption(ownerProjectId)
  84  |   await expect(applicationProject).toHaveValue(ownerProjectId)
  85  | 
  86  |   const applicationResponsePromise = page.waitForResponse(response => (
  87  |     response.request().method() === 'POST'
  88  |     && new URL(response.url()).pathname === '/api/v1/applications'
  89  |   ))
  90  |   await page.getByRole('button', { name: 'Add Application' }).click()
  91  |   const applicationPayload = await (await applicationResponsePromise).json()
  92  |   const application = record(applicationPayload, 'application')
  93  |   const applicationId = responseID(applicationPayload, 'create application', 'application')
  94  |   expect(application.project_id, 'application must belong to the project chosen in the UI').toBe(ownerProjectId)
  95  | 
  96  |   await expect(page.locator('button.settings-app-card').filter({ hasText: applicationName })).toBeVisible({ timeout: 15_000 })
  97  |   await expect(page.getByRole('button', { name: new RegExp(`Workspace context\\..*${ownerProjectName}`) })).toBeVisible()
  98  |   await expect.poll(() => routeScope(page.url()).get('projectId')).toBe(ownerProjectId)
  99  |   await expect.poll(() => routeScope(page.url()).get('applicationId')).toBe(applicationId)
  100 | 
  101 |   const storedApplication = await request.get(`/api/v1/applications/${applicationId}`)
  102 |   expect(storedApplication.ok()).toBeTruthy()
  103 |   expect(record(await storedApplication.json(), 'application').project_id).toBe(ownerProjectId)
  104 | 
  105 |   // Release creation in the sidebar changes active scope. The repository tabs
  106 |   // below then prove that the same hierarchy is visible on the S2 route.
  107 |   await page.getByRole('button', { name: /^Workspace context\./ }).click()
  108 |   await page.getByRole('button', { name: /Select release\. Current release:/ }).click()
  109 |   await page.getByRole('button', { name: 'New Release' }).click()
  110 |   const releaseDialog = page.getByRole('dialog', { name: 'New Release' })
  111 |   await releaseDialog.getByRole('textbox', { name: 'Name' }).fill(releaseName)
  112 |   const releaseResponsePromise = page.waitForResponse(response => (
  113 |     response.request().method() === 'POST'
  114 |     && new URL(response.url()).pathname === `/api/v1/projects/${ownerProjectId}/releases`
  115 |   ))
  116 |   await releaseDialog.getByRole('button', { name: 'Create release' }).click()
  117 |   const releasePayload = await (await releaseResponsePromise).json()
  118 |   const release = record(releasePayload, 'release')
  119 |   const releaseId = typeof release.application_release_id === 'string'
  120 |     ? release.application_release_id
  121 |     : responseID(releasePayload, 'create release', 'release')
  122 | 
  123 |   await expect(page.getByRole('button', { name: new RegExp(`Workspace context\\..*${releaseName}`) })).toBeVisible({ timeout: 15_000 })
  124 |   await expect.poll(() => routeScope(page.url()).get('releaseId')).toBe(releaseId)
  125 | 
  126 |   await page.getByRole('button', { name: 'Repository', exact: true }).click()
  127 |   await expect(page.getByRole('heading', { level: 1, name: 'Repository' })).toBeVisible({ timeout: 15_000 })
  128 | 
  129 |   const repositoryTabs = page.getByRole('tablist', { name: 'Repository asset types' })
  130 |   await repositoryTabs.getByRole('tab', { name: /Projects/ }).click()
  131 |   await expect(page.getByRole('main').getByRole('button', { name: ownerProjectName, exact: true }).first()).toBeVisible()
  132 |   await repositoryTabs.getByRole('tab', { name: /Releases/ }).click()
  133 |   await expect(page.getByRole('main').getByRole('button', { name: releaseName, exact: true }).first()).toBeVisible()
  134 | 
  135 |   const finalScope = routeScope(page.url())
  136 |   expect(finalScope.get('projectId')).toBe(ownerProjectId)
  137 |   expect(finalScope.get('applicationId')).toBe(applicationId)
  138 |   expect(finalScope.get('releaseId')).toBe(releaseId)
  139 |   return { label, domainId, categoryId, projectId: ownerProjectId, applicationId, releaseId }
  140 | }
  141 | 
  142 | export async function json(response: APIResponse | Response): Promise<Record<string, unknown>> {
> 143 |   expect(response.ok(), await response.text()).toBeTruthy()
      |                                                ^ Error: {"code":"import_draft_attestation_unavailable","error":"credential-preserving import draft could not be secured; retry the import","ref":"2b499579f8e4a5f3","retryable":true}
  144 |   return response.json()
  145 | }
  146 | export function idOf(payload: Record<string, unknown>, key?: string): string {
  147 |   return responseID(payload, 'resource', key)
  148 | }
  149 | /** The script editor's save state, as its status row shows it. */
  150 | export async function expectEditorSaved(page: Page) {
  151 |   await expect(page.getByRole('list', { name: 'Script status' }).getByRole('listitem').filter({ hasText: /^Saved/ })).toBeVisible()
  152 | }
  153 | 
  154 | /** The last debug run's outcome: Debug's session bar owns it, Author's status row repeats it. */
  155 | export async function expectDebugOutcome(page: Page, outcome: 'passed' | 'failed') {
  156 |   const badge = page.locator('.debug-session-bar .replay-live-badge').filter({ hasText: outcome === 'passed' ? /^Passed$/ : /^Failed$/ })
  157 |   const chip = page.getByRole('list', { name: 'Script status' }).getByRole('listitem').filter({ hasText: outcome === 'passed' ? /^Debugged/ : /^Debug failed/ })
  158 |   await expect(badge.or(chip).first()).toBeVisible()
  159 | }
  160 | 
  161 | export function mutation(page: Page, method: string, path: string) {
  162 |   return page.waitForResponse(r => r.request().method() === method && new URL(r.url()).pathname === path)
  163 | }
  164 | export async function login(page: Page, username = 'admin') {
  165 |   // Workflow tests share a controller and source IP. Pace real UI logins below
  166 |   // its ten-per-minute limit rather than retrying failures or weakening auth.
  167 |   await new Promise(resolve => setTimeout(resolve, 6500))
  168 |   await page.goto('/#/dashboard')
  169 |   await page.getByLabel('Username').fill(username)
  170 |   await page.getByLabel('Password').fill(username)
  171 |   await page.getByRole('button', { name: 'Sign in', exact: true }).click()
  172 |   await expect(page.getByRole('heading', { level: 1, name: 'Dashboard' })).toBeVisible()
  173 | }
  174 | /** The collapsed sidebar keeps the account card, with Sign out, behind its avatar; open it. */
  175 | export async function showAccountCard(page: Page) {
  176 |   const account = page.getByRole('button', { name: /Open account details$/ })
  177 |   if (await account.isVisible()) await account.click()
  178 | }
  179 | export async function signOut(page: Page) {
  180 |   await showAccountCard(page)
  181 |   await page.getByRole('button', { name: 'Sign out' }).click()
  182 | }
  183 | export async function seedScript(request: APIRequestContext, workspace: Workspace, name = 'Workflow_HTTP', baseURL = 'http://127.0.0.1:1', path = '/orders') {
  184 |   return idOf(await json(await request.post('/api/v1/scripts', { data: {
  185 |     project_id: workspace.projectId,
  186 |     script: { name, version: '1.0.0', protocol: 'http', config: { base_url: baseURL, pacing: { type: 'fixed_interval', interval_ms: 500 } }, actions: [{ name: 'orders', type: 'request', method: 'GET', target: path }] },
  187 |   } })))
  188 | }
  189 | export async function seedScenario(request: APIRequestContext, workspace: Workspace, scriptId: string, name = 'Workflow scenario') {
  190 |   return idOf(await json(await request.post('/api/v1/scenarios', { data: {
  191 |     project_id: workspace.projectId, application_id: workspace.applicationId, name, duration: '2m', scenario_mode: 'vuser_driven', groups: [{ name: 'orders', script_id: scriptId, vusers: 1, ramp_up: '1s' }],
  192 |   } })))
  193 | }
  194 | export async function importOpenAPI(page: Page, name: string, target: string) {
  195 |   await page.getByRole('button', { name: 'Scripts', exact: true }).click()
  196 |   // Navigate through the actual creation entry rather than seeding the script.
  197 |   await page.getByRole('button', { name: 'Script builder', exact: true }).first().click()
  198 |   await page.getByRole('tab', { name: 'Import', exact: true }).click()
  199 |   await page.getByRole('button', { name: /OpenAPI \/ Swagger/ }).click()
  200 |   const controls = page.getByRole('group', { name: 'Script import controls' })
  201 |   const spec = { openapi: '3.0.3', info: { title: name, version: '1.0' }, servers: [{ url: target }], paths: { '/orders': { get: { operationId: 'listOrders', responses: { '200': { description: 'Orders' } } } } } }
  202 |   await controls.locator('input[type=file]').setInputFiles({ name: 'orders.openapi.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(spec)) })
  203 |   await controls.getByRole('textbox', { name: 'Script Name' }).fill(name)
  204 |   await controls.getByText('Advanced validation only', { exact: true }).click()
  205 |   await controls.getByRole('button', { name: 'Validate Only' }).click()
  206 |   await expect(controls.getByText(/dry-run validation; nothing has been saved/i)).toBeVisible()
  207 |   await controls.locator('.import-source-setup > summary').click()
  208 |   await controls.getByRole('button', { name: 'Inspect & review' }).click()
  209 |   await expect(controls.getByRole('heading', { name: 'Review Generated Script' })).toBeVisible()
  210 |   const saved = mutation(page, 'POST', '/api/v1/scripts/import/openapi/commit')
  211 |   await controls.getByRole('button', { name: 'Save draft' }).click()
  212 |   const scriptId = idOf(await json(await saved), 'stored_script')
  213 |   await controls.getByRole('button', { name: `Open ${name} in Visual Editor`, exact: true }).click()
  214 |   return scriptId
  215 | }
  216 | export async function buildScenarioUI(page: Page, scriptName: string, name: string) {
  217 |   await page.getByRole('button', { name: 'New run', exact: true }).first().click()
  218 |   await page.getByRole('button', { name: 'Open scenario builder' }).click()
  219 |   const steps = page.locator('[aria-label="Scenario builder steps"]')
  220 |   await page.getByPlaceholder('Scenario name').fill(name)
  221 |   await page.getByRole('button', { name: 'Add script to Group 1' }).click()
  222 |   await page.getByRole('row').filter({ hasText: scriptName }).getByRole('button', { name: 'Use for Group 1' }).click()
  223 |   await steps.getByRole('button', { name: /^Model/ }).click()
  224 |   await page.getByRole('button', { name: /^Fixed VUsers/ }).click()
  225 |   await page.getByRole('button', { name: 'Use Closed VUser', exact: true }).click()
  226 |   await steps.getByRole('button', { name: /^Run settings/ }).click()
  227 |   const scenarioTabs = page.getByRole('tablist', { name: 'Run settings sections' })
  228 |   await scenarioTabs.getByRole('tab', { name: 'Run phases' }).click()
  229 |   await page.getByLabel('Ramp-up', { exact: true }).fill('1')
  230 |   await page.getByLabel('Ramp-up Unit').selectOption('s')
  231 |   await page.getByLabel('Sustained load', { exact: true }).fill('1')
  232 |   await page.getByLabel('Sustained load Unit').selectOption('m')
  233 |   await scenarioTabs.getByRole('tab', { name: 'Target load' }).click()
  234 |   await page.getByLabel('Peak VUsers', { exact: true }).fill('1')
  235 |   await steps.getByRole('button', { name: /^Data/ }).click()
  236 |   await page.getByRole('button', { name: 'Next', exact: true }).click()
  237 |   await expect(page.getByRole('heading', { name: 'Review and validate' })).toBeVisible()
  238 |   const saved = mutation(page, 'POST', '/api/v1/scenarios')
  239 |   await page.getByRole('button', { name: 'Save and configure run' }).click()
  240 |   const payload = await json(await saved)
  241 |   return idOf(payload)
  242 | }
  243 | export async function runStatus(request: APIRequestContext, id: string) {
```