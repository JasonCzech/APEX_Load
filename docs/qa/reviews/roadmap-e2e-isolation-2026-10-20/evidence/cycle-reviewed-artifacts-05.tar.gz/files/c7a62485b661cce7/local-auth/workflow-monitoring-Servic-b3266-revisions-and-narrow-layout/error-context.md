# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-monitoring.spec.ts >> Service Bus authoring preserves explicit queue and subscription approval, revisions and narrow layout
- Location: e2e/workflow-monitoring.spec.ts:627:1

# Error details

```
Error: Channel closed
```