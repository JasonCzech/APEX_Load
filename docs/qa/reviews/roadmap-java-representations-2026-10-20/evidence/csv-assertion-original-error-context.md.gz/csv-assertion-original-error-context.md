# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow-java-representation.spec.ts >> Java native panel saves and reopens paired sums with compression and missing evidence in CSV
- Location: e2e/workflow-java-representation.spec.ts:48:1

# Error details

```
Error: expect(received).toContain(expected) // indexOf

Expected substring: ",7,measured,gzip"
Received string:    "﻿\"Elapsed seconds\",\"Current (ratio)\",\"Baseline (ratio)\",\"Measured observations\",\"Availability\",\"Current prepared-body compression\",\"Baseline measured observations\",\"Baseline availability\",\"Baseline prepared-body compression\"·
\"0\",\"0.5\",\"0\",\"2\",\"measured\",\"gzip\",\"7\",\"measured\",\"gzip\"·
\"10\",\"\",\"\",\"0\",\"measurement_unavailable\",\"gzip\",\"3\",\"incomplete_representation_evidence\",\"gzip\"·
"
```

# Page snapshot

```yaml
- generic [ref=f2e3]:
  - link "Skip to main content" [ref=f2e4] [cursor=pointer]:
    - /url: "#app-main"
  - complementary [ref=f2e6] [cursor=pointer]:
    - button "APEX Load dashboard" [ref=f2e7]:
      - img "APEX Load" [ref=f2e8]
    - button "Workspace context. e2e-1792495586429-886214 domain / e2e-1792495586429-886214 project / e2e-1792495586429-886214 application / e2e-1792495586429-886214 1.0" [ref=f2e15]:
      - generic [aria-hidden] [ref=f2e16]: ◈
    - navigation "Primary navigation" [ref=f2e17]:
      - button "New run" [ref=f2e19]
      - generic [ref=f2e24]:
        - button "Dashboard" [ref=f2e26]
        - button "Command Center" [ref=f2e34]
        - button "Results" [ref=f2e41]
        - button "Monitoring" [ref=f2e45]
        - button "Activity" [ref=f2e50]
      - generic [ref=f2e54]:
        - button "Scripts" [ref=f2e56]
        - button "Scenarios" [ref=f2e62]
        - button "Shared assets" [ref=f2e67]
      - generic [ref=f2e73]:
        - button "Repository" [ref=f2e75]
        - button "Access" [ref=f2e81]
        - button "Settings" [ref=f2e88]
      - button "Help & documentation" [ref=f2e95]
    - generic [ref=f2e100]:
      - generic [ref=f2e101]:
        - 'button "Preview permissions. Current mode: Admin" [ref=f2e104]':
          - generic [aria-hidden] [ref=f2e105]: DEV
        - generic [ref=f2e106]:
          - 'status "Live connection: Live" [ref=f2e107]':
            - generic [ref=f2e109]:
              - generic [ref=f2e110]: "Live connection:"
              - text: Live
          - 'button "Build info: local · dev" [ref=f2e112]'
      - button "Expand sidebar" [ref=f2e115]
  - main [active] [ref=f2e118]:
    - status [ref=f2e119]: Run results
    - generic "Dashboard controls" [ref=f2e120]:
      - heading "Run results" [level=1] [ref=f2e122]
      - generic [ref=f2e123]:
        - link "Help for this page" [ref=f2e124] [cursor=pointer]:
          - /url: "#/docs?guide=user-guide&article=results"
        - generic "Deployment identity" [ref=f2e125]:
          - generic "You are using APEX Load in a web browser; tests run on the Server controller." [ref=f2e126]:
            - text: Web app · Server
            - generic [ref=f2e128]: . You are using APEX Load in a web browser; tests run on the Server controller.
        - combobox "Dashboard color theme" [ref=f2e130] [cursor=pointer]:
          - option "System (Auto)"
          - option "Dark Theme"
          - option "Light Theme" [selected]
          - option "Solarized Dark"
          - option "Solarized Light"
          - option "Monokai Dimmed"
    - generic [ref=f2e131]:
      - generic [ref=f2e132]:
        - generic [ref=f2e133]:
          - paragraph [ref=f2e134]: Run results · LOC-RUN-20261020-002
          - heading "Java native panel" [level=2] [ref=f2e135]
          - paragraph [ref=f2e136]:
            - generic [ref=f2e137]: ABORTED
            - text: · Configured 1 VUsers for 1s · Lifecycle elapsed Not recorded
        - generic [ref=f2e139]:
          - button "Compare" [disabled] [ref=f2e140]
          - button "Export report" [disabled] [ref=f2e141]
          - button "Copy link" [ref=f2e142] [cursor=pointer]
          - button "Run notes" [ref=f2e143] [cursor=pointer]
      - region "Execution outcome" [ref=f2e144]:
        - heading "Execution aborted" [level=2] [ref=f2e145]
        - paragraph [ref=f2e146]: test cancelled before start
        - paragraph [ref=f2e147]: Execution status is separate from sampled transaction success and performance acceptance.
      - region "Evidence availability" [ref=f2e148]:
        - generic [ref=f2e149]:
          - heading "Saved archive unavailable" [level=2] [ref=f2e150]
          - paragraph [ref=f2e151]: Retained controller records are available below. Archive publication progress is unknown; these records do not establish complete workload or performance evidence.
        - button "Check again" [ref=f2e152] [cursor=pointer]
      - group [ref=f2e153]:
        - generic "Run timeline annotations" [ref=f2e154] [cursor=pointer]
      - tablist "Result sections" [ref=f2e155]:
        - tab "Summary" [selected] [ref=f2e156] [cursor=pointer]
        - tab "Performance" [ref=f2e157] [cursor=pointer]
        - tab "Baseline comparison" [ref=f2e158] [cursor=pointer]
        - tab "Diagnostics" [ref=f2e159] [cursor=pointer]
        - tab "Evidence" [ref=f2e160] [cursor=pointer]
        - tab "Execution" [ref=f2e161] [cursor=pointer]
      - tabpanel "Summary" [ref=f2e162]:
        - generic "Execution facts" [ref=f2e163]:
          - generic [ref=f2e164]:
            - term [ref=f2e165]: Configured duration
            - definition [ref=f2e166]: 1s
          - generic [ref=f2e167]:
            - term [ref=f2e168]: Lifecycle elapsed
            - definition [ref=f2e169]: Not recorded
          - generic [ref=f2e170]:
            - term [ref=f2e171]: Configured VUsers
            - definition [ref=f2e172]: "1"
          - generic [ref=f2e173]:
            - term [ref=f2e174]: Observed peak VUsers
            - definition [ref=f2e175]: Not recorded
        - generic [ref=f2e176]:
          - heading "Investigate this run" [level=2] [ref=f2e177]
          - paragraph [ref=f2e178]: Performance acceptance is not assessed here. Review the recorded reason, lifecycle events, and available evidence before deciding whether to rerun.
          - generic [ref=f2e179]:
            - button "Review execution events" [ref=f2e180] [cursor=pointer]
            - button "View retained evidence" [ref=f2e181] [cursor=pointer]
```

# Test source

```ts
  1   | import { test, expect, seedScript, json, idOf, login } from './support/workflow'
  2   | import { createWorkspace, scopeQuery } from './support/workspace'
  3   | import { javaHTTPFixture } from '../src/utils/javaHttpTestFixtures'
  4   | 
  5   | test.afterEach(async ({ page }) => { await page.unrouteAll({ behavior: 'wait' }) })
  6   | 
  7   | // Transport, persistence and raw measurement arithmetic use real Go integration
  8   | // fixtures. These controlled responses exercise the real authenticated UI and
  9   | // project panel persistence, without running a customer or Java target.
  10  | test('Java representations retain their own live action population and archived report evidence', async ({ page, trackRun }) => {
  11  |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  12  |   const request = page.context().request, workspace = await createWorkspace(request)
  13  |   const scriptId = await seedScript(request, workspace)
  14  |   const id = idOf(await json(await request.post('/api/v1/tests', { data: { project_id: workspace.projectId, application_id: workspace.applicationId, release_id: workspace.releaseId, name: 'Java representations', duration: '2m', groups: [{ name: 'requests', script_id: scriptId, vusers: 1 }] } })))
  15  |   trackRun(id)
  16  |   const diagnostics = javaHTTPFixture()
  17  |   let archived = false, available = false
  18  |   await page.route(`**/api/v1/tests/${id}`, async route => {
  19  |     if (route.request().method() !== 'GET') return route.continue()
  20  |     const response = await route.fetch(), record = await response.json()
  21  |     return route.fulfill({ response, json: { ...record, status: archived ? 'COMPLETE' : 'RUNNING', ...(archived ? { archive: { transaction_count: 2 }, started_at: '2026-10-01T00:00:00Z', ended_at: '2026-10-01T00:00:02Z' } : {}), live_metrics: { total_transactions: 999, total_errors: 0, active_vusers: 1, transactions: {}, ...(available ? { java_http: { version: 1, actions: { 'Read object': { population: 2, diagnostics } } } } : {}) } } })
  22  |   })
  23  |   await page.route(`**/api/v1/tests/${id}/archive/report*`, route => route.fulfill({ json: { manifest: { test_id: id, test_name: 'Java representations', status: 'COMPLETE', provenance: { started_at: '2026-10-01T00:00:00Z', duration: '2s', total_vusers: 1 } }, overview: { transactions: 999 }, by_action: { 'Read object': { transactions: 3, actual_action_samples: 2, java_http: diagnostics } } } }))
  24  |   await page.goto(`/#/test/${id}?tab=diagnostics&${scopeQuery(workspace)}`); await page.reload()
  25  |   const panel = page.getByRole('region', { name: 'Java HTTP representation diagnostics', exact: true })
  26  |   await expect(page.getByText('Create project analytics panel', { exact: true })).toBeVisible()
  27  |   await expect(panel).toHaveCount(0)
  28  |   available = true
  29  |   await expect(panel).toBeVisible()
  30  |   await panel.getByText('Read object', { exact: true }).click()
  31  |   await expect(panel).toContainText('Observed diagnostics: 1 of 2 action executions')
  32  |   await expect(panel).toContainText('Retained response: 0 bytes mean')
  33  |   await expect(panel).toContainText('Base64 / retained response: Unavailable')
  34  |   await expect(panel).toContainText('Coverage incomplete')
  35  |   await expect(panel).toContainText('JVM object footprint is unavailable')
  36  |   await page.setViewportSize({ width: 760, height: 900 })
  37  |   await panel.screenshot({ path: test.info().outputPath('java-live-representations.png') })
  38  |   archived = true
  39  |   await page.goto(`/#/report/${id}?section=diagnostics&${scopeQuery(workspace)}`); await page.reload()
  40  |   await page.getByRole('tab', { name: 'Diagnostics', exact: true }).click()
  41  |   await expect(panel).toBeVisible()
  42  |   await panel.getByText('Read object', { exact: true }).click()
  43  |   await expect(panel).toContainText('Observed diagnostics: 1 of 2 action executions')
  44  |   await expect(panel).toContainText('Prepared request compression: none 1; gzip 0; deflate 0')
  45  |   await panel.screenshot({ path: test.info().outputPath('java-archive-representations.png') })
  46  | })
  47  | 
  48  | test('Java native panel saves and reopens paired sums with compression and missing evidence in CSV', async ({ page, trackRun }) => {
  49  |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  50  |   const request = page.context().request, workspace = await createWorkspace(request)
  51  |   const scriptId = await seedScript(request, workspace)
  52  |   const id = idOf(await json(await request.post('/api/v1/tests', { data: { project_id: workspace.projectId, application_id: workspace.applicationId, release_id: workspace.releaseId, name: 'Java native panel', duration: '1s', groups: [{ name: 'requests', script_id: scriptId, vusers: 1 }] } })))
  53  |   trackRun(id)
  54  |   let reads = 0
  55  |   await page.route(`**/api/v1/tests/${id}/archive/native-series`, route => {
  56  |     const query = route.request().postDataJSON()
  57  |     expect(query).toMatchObject({ population: 'java_http_action', metric: 'java_http_prepared_per_decoded', aggregation: 'ratio_of_sums', filters: { action: 'Read object' }, comparison_run_id: 'java-reference', end_seconds: 20, bucket_seconds: 10, max_series: 1 })
  58  |     expect(query).not.toHaveProperty('evidence_mode'); reads++
  59  |     return route.fulfill({ json: { current: { run_id: id, unit: 'ratio', java_http_compression: 'gzip', warnings: [], identities: ['Read object'], buckets: [{ from: '2026-10-01T00:00:00Z', to: '2026-10-01T00:00:10Z', offset_seconds: 0, count: 2, value: .5 }, { from: '2026-10-01T00:00:10Z', to: '2026-10-01T00:00:20Z', offset_seconds: 10, count: 0, value: null, reason: 'measurement_unavailable' }] }, baseline: { run_id: 'java-reference', unit: 'ratio', java_http_compression: 'gzip', warnings: [], identities: ['Read object'], buckets: [{ from: '2026-10-01T00:00:00Z', to: '2026-10-01T00:00:10Z', offset_seconds: 0, count: 7, value: 0 }, { from: '2026-10-01T00:00:10Z', to: '2026-10-01T00:00:20Z', offset_seconds: 10, count: 3, value: null, reason: 'incomplete_representation_evidence' }] }, comparable: false, warnings: [], added: [], removed: [] } })
  60  |   })
  61  |   await page.goto(`/#/test/${id}?${scopeQuery(workspace)}`); await page.reload()
  62  |   await page.getByText('Create project analytics panel', { exact: true }).click()
  63  |   await page.getByLabel('Panel title', { exact: true }).fill('Java representation ratio')
  64  |   await page.getByRole('combobox', { name: 'Evidence population', exact: true }).selectOption('java_http_action')
  65  |   await expect(page.getByRole('button', { name: 'Save project panel', exact: true })).toBeDisabled()
  66  |   await page.getByLabel('Exact action or transaction name', { exact: true }).fill('Read object')
  67  |   await page.getByRole('combobox', { name: 'Metric', exact: true }).selectOption('java_http_prepared_per_decoded')
  68  |   await expect(page.getByRole('combobox', { name: 'Measurement', exact: true })).toHaveValue('ratio_of_sums')
  69  |   await page.getByLabel('End elapsed seconds', { exact: true }).fill('20')
  70  |   await page.getByLabel('Comparison run ID (optional)', { exact: true }).fill('java-reference')
  71  |   await page.getByRole('combobox', { name: 'Visualization', exact: true }).selectOption('table')
  72  |   await page.getByRole('button', { name: 'Save project panel', exact: true }).click()
  73  |   const panels = page.getByRole('region', { name: 'Project analytics panels', exact: true })
  74  |   await expect(panels).toContainText('Java representation ratio')
  75  |   await page.reload()
  76  |   await expect(panels).toContainText('Prepared-body compression: current gzip')
  77  |   expect(reads).toBeGreaterThan(1)
  78  |   await panels.getByText('Inspect time buckets (2)', { exact: true }).click()
  79  |   await expect(panels).toContainText('Missing (measurement unavailable)')
  80  |   await expect(panels).toContainText('Missing (incomplete representation evidence)')
  81  |   await expect(panels.getByRole('columnheader', { name: 'Baseline measured observations', exact: true })).toBeVisible()
  82  |   await expect(panels.getByRole('cell', { name: '7', exact: true })).toBeVisible()
  83  |   await expect(panels.getByRole('button', { name: /Inspect current bucket/ })).toHaveCount(0)
  84  |   const pending = page.waitForEvent('download')
  85  |   await panels.getByRole('button', { name: 'Export Java representation ratio data as CSV', exact: true }).click()
  86  |   const download = await pending, stream = await download.createReadStream()
  87  |   const chunks: Buffer[] = []; for await (const chunk of stream!) chunks.push(Buffer.from(chunk))
  88  |   const csv = Buffer.concat(chunks).toString('utf8')
  89  |   expect(csv).toContain('Current (ratio)'); expect(csv).toContain('0.5'); expect(csv).toContain('measurement_unavailable'); expect(csv).toContain('gzip')
> 90  |   expect(csv).toContain('Baseline measured observations'); expect(csv).toContain('Baseline availability'); expect(csv).toContain('incomplete_representation_evidence'); expect(csv).toContain(',7,measured,gzip')
      |                                                                                                                                                                                     ^ Error: expect(received).toContain(expected) // indexOf
  91  |   await page.setViewportSize({ width: 760, height: 900 })
  92  |   await panels.screenshot({ path: test.info().outputPath('java-native-panel.png') })
  93  | })
  94  | 
  95  | test('Java baseline detail retains per-run populations and versioned evidence in its export', async ({ page, trackRun }) => {
  96  |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  97  |   const request = page.context().request, workspace = await createWorkspace(request)
  98  |   const scriptId = await seedScript(request, workspace)
  99  |   const id = idOf(await json(await request.post('/api/v1/tests', { data: { project_id: workspace.projectId, application_id: workspace.applicationId, release_id: workspace.releaseId, name: 'Java baseline evidence', duration: '2m', groups: [{ name: 'requests', script_id: scriptId, vusers: 1 }] } })))
  100 |   trackRun(id)
  101 |   const identity = { id, name: 'Current Java run', release_id: 'release', release_name: 'Release', scenario_id: 'scenario', status: 'COMPLETE', vusers: 1, peak_vusers: 1, pinned: true, archive_available: true }
  102 |   const baseline = { ...identity, id: 'java-baseline', name: 'Java baseline' }
  103 |   const window = { start_seconds: 30, end_seconds: 120, load: 1, total_load: 1, group: 'requests', direction: 'steady', mix: { requests: 1 } }
  104 |   const measurement = { samples: 2, successes: 2, errors: 0, mean: 10, min: 10, max: 10, p50: 10, p90: 10, p95: 10, p99: 10, throughput: 1, successful_throughput: 1, error_pct: 0, coverage_pct: 100, instances: 1, points: [], java_http: javaHTTPFixture() }
  105 |   const { defaultPolicy } = await import('../src/components/baselineComparison/model')
  106 |   const snapshot = { id: 'java-snapshot', project_id: workspace.projectId, current: identity, baselines: [baseline], created_at: '2026-10-01T00:00:00Z', rule_version: 'baseline-comparison-v1', request: { baseline_ids: [baseline.id], population: 'action' }, policy: defaultPolicy, transactions: [{ id: 'tx/0', name: 'Read object', group: 'requests', protocol: 'java_http', source: 'action', unit: 'ms', window, current: measurement, baselines: { [baseline.id]: { measurement: { ...measurement, samples: 1, successes: 1 }, window, qualification: ['Partial diagnostics'], approximate: false } } }], resources: [], setup: [], findings: [], warnings: [] }
  107 |   await page.route(`**/api/v1/tests/${id}/baseline-comparisons/java-snapshot`, route => route.fulfill({ json: snapshot }))
  108 |   await page.route(`**/api/v1/tests/${id}/baseline-candidates*`, route => route.fulfill({ json: { runs: [baseline], total: 1 } }))
  109 |   await page.route('**/api/v1/scenarios/*/comparison-policy', route => route.fulfill({ json: defaultPolicy }))
  110 |   await page.route(`**/api/v1/tests/${id}`, async route => { if (route.request().method() !== 'GET') return route.continue(); const response = await route.fetch(), record = await response.json(); return route.fulfill({ response, json: { ...record, scenario_id: 'scenario', status: 'COMPLETE', archive: { transaction_count: 2 }, started_at: '2026-10-01T00:00:00Z', ended_at: '2026-10-01T00:02:00Z' } }) })
  111 |   await page.route(`**/api/v1/tests/${id}/archive/report*`, route => route.fulfill({ json: { manifest: { test_id: id, test_name: 'Java baseline evidence', status: 'COMPLETE', provenance: { total_vusers: 1, duration: '2m', started_at: '2026-10-01T00:00:00Z' } }, overview: { transactions: 2 }, by_action: {} } }))
  112 |   await page.goto(`/#/report/${id}?section=comparison&comparison_id=java-snapshot&${scopeQuery(workspace)}`); await page.reload()
  113 |   await page.getByRole('button', { name: 'Read object', exact: true }).click()
  114 |   const drawer = page.getByRole('dialog', { name: 'Read object', exact: true })
  115 |   for (const [name, count] of [['Current', 2], ['Java baseline', 1]] as const) {
  116 |     const evidence = drawer.getByRole('region', { name: `Java representation evidence for ${name}`, exact: true })
  117 |     await evidence.getByText('Read object', { exact: true }).click()
  118 |     await expect(evidence).toContainText(`Observed diagnostics: 1 of ${count} action executions`)
  119 |     await expect(evidence).toContainText('Retained response: 0 bytes mean')
  120 |   }
  121 |   await expect(drawer).toContainText('Partial diagnostics')
  122 |   const pending = page.waitForEvent('download')
  123 |   await drawer.getByRole('button', { name: 'Export Read object comparison data as CSV', exact: true }).click()
  124 |   const stream = await (await pending).createReadStream(), chunks: Buffer[] = []
  125 |   for await (const chunk of stream!) chunks.push(Buffer.from(chunk))
  126 |   const csv = Buffer.concat(chunks).toString('utf8')
  127 |   expect(csv).toContain('Java action population'); expect(csv).toContain('unavailable_embedded_opaque_bytes'); expect(csv).toContain('response_retained')
  128 |   await page.setViewportSize({ width: 760, height: 900 })
  129 |   await drawer.screenshot({ path: test.info().outputPath('java-baseline-detail.png') })
  130 | })
  131 | 
  132 | 
  133 | test('Java representation help remains searchable and qualified after reload', async ({ page }) => {
  134 |   if (process.env.APEXLOAD_E2E_PROFILE === 'local-auth') await login(page)
  135 |   await page.goto('/#/docs')
  136 |   await page.getByRole('searchbox', { name: 'Search all help articles' }).fill('opaque representations')
  137 |   await page.locator('.help-search-results').getByRole('link', { name: 'Web/API execution support', exact: true }).click()
  138 |   await expect(page).toHaveURL(/article=web-api-support/)
  139 |   const article = page.locator('.guide-markdown-article')
  140 |   await expect(article).toContainText('each with its own observed count')
  141 |   await expect(article).toContainText('do not measure JVM object footprint')
  142 |   await page.reload()
  143 |   await expect(article).toContainText('distributed source-window qualification remains open')
  144 |   await page.setViewportSize({ width: 760, height: 900 })
  145 |   await page.getByRole('heading', { name: 'Diagnostics', exact: true }).scrollIntoViewIfNeeded()
  146 |   await page.screenshot({ path: test.info().outputPath('java-representation-help.png') })
  147 | })
  148 | 
```